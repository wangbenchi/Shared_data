% toi_mean = squeeze(mean(toi,2));
% epoch = [200 400];
% epoch_index =dsearchn(toi_mean,epoch');



%time_mean_RSM = atanh(location_time_raw_mean);

% mycolorpoint = [[237,229,27];...
% [139,213,69];...
% [34,167,133];...
% [34,138,142];...
% [57,86,139];...
% [72,29,111]];

mycolorpoint=[[72,29,111];...
[57,86,139];...
[34,138,142];...
[34,167,133];...
[139,213,69];...
[237,229,27]]
% mycolorpoint=[[23,77,134];...
%     [23,77,134];...
%     [247,251,253];...
%     [211,89,72];...
%     [176,31,44];...
%     [124,18,34]];
mycolorposition=[1 5 20 40 50 64];
mycolormap_r=interp1(mycolorposition,mycolorpoint(:,1),1:64,'linear','extrap');
mycolormap_g=interp1(mycolorposition,mycolorpoint(:,2),1:64,'linear','extrap');
mycolormap_b=interp1(mycolorposition,mycolorpoint(:,3),1:64,'linear','extrap');
mycolor=[mycolormap_r',mycolormap_g',mycolormap_b']/255;
mycolor=round(mycolor*10^4)/10^4;%保留4位小数


 
map=round(100*[23,77,134;
27,87,158;
42,122,184;
52,136,191;
66,146,195;
109,175,209;
159, 203,225;
247,251,253;
252,203,176;
243,166,131;
232,133,102;
211,89,72;
176,31,44;
124,18,34]/255)/100;

region_ele_1 = size(realmean,1);
region_ele_2 = size(realmean,2);
ele_time_raw_mean = squeeze(mean(location_time_raw_mean));
region_1_ele = [1:region_ele_1];
region_2_ele = [1:region_ele_2];

x_range = [1 region_ele_1];
y_range = [1 region_ele_2];

% plot tresholded results
fontsize = 42;
realmean(find(tmapthresh==0)) = 0;
figure('position',[50,50,600,700]), clf
image(region_2_ele,region_1_ele,realmean,'CDataMap','scale')

colormap(mycolor)
% H_color = colorbar()
% H_color.Ticks = [0 0.1 0.2 0.3];
set(gca,'clim',[0 0.3],'xlim',xlim,'ydir','norm')
set(gca,'FontSize',fontsize)
%title([region],'FontSize',fontsize)
%view(-90,90)
ax2 = gca()

%xlabel('prc','FontSize',fontsize), ylabel('prc','FontSize',fontsize)
set(gca,'TickDir','out')
box off
set(ax2,'Ytick',[]);
set(ax2,'Xtick',[]);

index = length(find(tmapthresh~=0))./(region_ele_1*region_ele_2)*100
