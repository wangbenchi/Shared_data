     region_1_data = location_data;
      region_2_data = location_data;
      
      region_1_name = 'PFC';
      region_2_name = 'IP';
      region_ele_1 = size(region_1_data,2);
      region_ele_2 = size(region_2_data,2);
      clear location_data
      %location_data = cat(2,region_1_data,region_2_data);
     number_ran = randi([1,100000]);
     seed = rng(number_ran);
      %location_data = all_data;
        trials=60
        %trials = size(location_data,4);
        half_trial = floor(trials/2);
        time = [-500 1500];
        window = 200;
        step = 10;
        key = 1;
        number = 1;
%         toi=[];
%         while key
%             toi(number,:)  =[time(1)+step*(number-1) time(1)+step*(number-1)+window];
%             if toi(number,2)<=time(end)
%                 number = number +1;
%             else
%                 key = 0;
%             end
%         end
%         toi(end,:)=[]; 
         toi =[100  400];
        %nElectrodes = size(location_data,2);
        %nElectrodes = 114;
        location_time_raw=[];
        ele_time_raw=[];
        ele_time_same=[];
        ele_time_diff=[];
        
        ele_time_between=[];
        ele_time_within=[];
        for iter = 1:30
            tic
            %ele_ran = shuffle([1:253]);
            trial_list =shuffle([1:trials]);
            pre_list = trial_list(1:5);
            trial_list =shuffle([1:trials]);
            post_list = trial_list(end+1-5:end);
            pre_location_data = squeeze(mean(region_1_data(:,:,:,pre_list),4));
            post_location_data = squeeze(mean(region_2_data(:,:,:,post_list),4));

          for t = 1:size(toi,1) % 这里是为了看瞬时的power %% 
            win_time = toi(t,:);
            toi_index = dsearchn(dim.times',win_time');
   
            pre_data = squeeze(pre_location_data(:,:,toi_index(1):toi_index(end)));
            post_data = squeeze(post_location_data(:,:,toi_index(1):toi_index(end)));

            toi_nsample = size(pre_data,3);
            
            pre_data = permute(pre_data,[3,1,2]);
            post_data = permute(post_data,[3,1,2]);
            
            
            pre_data = reshape(pre_data,[toi_nsample,size(pre_location_data,2)*8]);
            post_data = reshape(post_data,[toi_nsample,size(post_location_data,2)*8]);
            
            coef = corr(pre_data, post_data, 'type','Spearman' );
            coef_res = reshape(coef,[8,size(pre_location_data,2),8,size(post_location_data,2)]);
             for n = 1:8
                U = squeeze(coef_res(n,:,n,:));
                U_diag = diag(U);
                U_other = U(~eye(size(U_diag,1)));
                location_time_raw(iter,t,n,:,:) = U;
%                 location_time_same(iter,t,n) = mean(U_diag);
%                 location_time_diff(iter,t,n) = mean(U_other);
             end
%               for n = 1:8
%                 U = squeeze(coef_res(n,:,n,:));
%                 ele_time_within_region_1= U(1:region_ele_1,1:region_ele_1);
%                 ele_time_within_region_2= U(end-region_ele_2+1:end,end-region_ele_2+1:end);
%                 
%                 region_2_diag = diag(ele_time_within_region_2);
%                 region_2_other  = ele_time_within_region_2(~eye(size(region_2_diag,1)));
%                 
%                 region_1_diag = diag(ele_time_within_region_1);
%                 region_1_other  = ele_time_within_region_1(~eye(size(region_1_diag,1)));
%                 
%                 ele_time_between_region_1 = U(1:region_ele_1,end-region_ele_2+1:end);
%                 ele_time_between_region_2 = U(end-region_ele_2+1:end,1:region_ele_1);
%                 
%                 
%                 all_within = cat(1,region_2_other,region_1_other);
%                 all_between = cat(1,ele_time_between_region_1(:),ele_time_between_region_2(:));
%                 
%                
%                 %ele_time_raw(iter,t,n,:) = U(:);
%                 
%                 ele_time_between(iter,t,n,:) = all_between;
%                 ele_time_within(iter,t,n,:) = all_within;
%                 
%              end

          end
          toc
        end


 location_time_raw_mean = squeeze(mean(location_time_raw,3));
time_mean_RSM = atanh(location_time_raw_mean);

        data_folder_within = ['J:\SL整理\Spatial R\attentional capture\2023.10.17 剔除病灶电极\bewteen region\']; %% save path
          if ~exist(data_folder_within)
            mkdir(data_folder_within)
        end
        data_path= [data_folder_within filesep region_1_name '_' region_2_name '_iter_5_trials_100_400'];
        location_time_raw_mean = squeeze(mean(location_time_raw,3));
        save(data_path,'toi','location_time_raw_mean','region_ele_1','region_ele_2','-v7.3');
        clc,clear
            
        
        
        
        
    end
end

