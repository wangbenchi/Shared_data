


conn = 8;


%X1_cluster = X2_cluster;
colormap = round(100*[224 234 247;
                    48 129 191; ...
                     16 55 120]/255)/100;
 color_map={'#ff00ff';'#EC8D5F';'#0BB1D9'};
 RGB = validatecolor(colormap,'multiple');


color_map = round(100*[224 234 247;
                    48 129 191; ...
                     16 55 120]/255)/100;
 color_map={'#ff00ff';'#EC8D5F';'#0BB1D9'};
 RGB = validatecolor(color_map,'multiple');
color_map = RGB;
color_map(4,:) = [255,77,255]/256;
% 
% color_map =[235,104,107]/256;
%  color_map=[
%       19,107,28;
%      255,77,255;
%      241,136,101;
%      107,170,201;
%        66 34 86]/256;
list_number = [1 4];
line_1_data = 1.044;
line_2_data = 1.460;
line_1_number = 3;
line_2_number = 2;
    fontsize = 46;
    figure('position',[1,1,1200,800]), clf
    set(gca,'FontSize',fontsize)
    [l,p] = boundedline(tftime,squeeze(mean(X1)),squeeze(std(X1))./sqrt(nSubjects),'cmap',color_map(line_1_number,:),'alpha','transparency',.3);
    h(1)=l;
    [l,p] = boundedline(tftime,squeeze(mean(X2)),squeeze(std(X1))./sqrt(nSubjects),'cmap',color_map(line_2_number,:),'alpha','transparency',.3);
    h(2)=l;
    hold on;
    plot(tftime,squeeze(mean(X1)),'Color',color_map(line_1_number,:),'LineWidth',7);hold on
    plot(tftime,squeeze(mean(X2)),'Color',color_map(line_2_number,:),'LineWidth',7);
%     H = legend(h,'Present','absent');
%     H.EdgeColor = [1,1,1];
%     H.Position = [0.55 0.73 0.2 0.2]
%     set(h,'LineWidth',5)
%     set(h(1),'Color',color_map(line_1_number,:))
%     set(h(2),'Color',clolor_map(line_2_number,:))
%     set(legend,'FontSize',fontsize,'Location','northeastoutside')
%     set(legend,'FontSize')
%     set(legend,'AutoUpdate','off')
    yl=get(gca,'ylim');
    ax = gca;
    ax.YLim = [-0.15 0.2];
    ax.XLim = [-500 4000];
    ax.LineWidth = 6;
    set(gca,'XTick',[-0:1000:4000])
    yl=get(gca,'ylim');
    set(gca,'YTick',[ -0.2 -0.1 0  0.1 0.2])
%     line([line_1_data*1000 line_1_data*1000],[min(yl) max(yl)],'Color',clolor_map(line_1_number,:),'LineWidth',7,'LineStyle','--');
%     line([line_2_data*1000 line_2_data*1000],[min(yl) max(yl)],'Color',clolor_map(line_2_number,:),'LineWidth',7,'LineStyle','--');
    set(gca,'TickDir','out')
    %axis square
    %title([region],'FontSize',fontsize)
    xlabel('Time (ms)','FontSize',fontsize), 
    ylabel(['Power (Z) '],'FontSize',fontsize)
    %set(gca,'YTick',[-0.02 0 0.1 0.2  0.3])
    hold on

    %% diff
     plotclust = bwconncomp(diff_cluster,conn);
    for blob=1:plotclust.NumObjects;
        plot([tftime(plotclust.PixelIdxList{blob}(1)) tftime(plotclust.PixelIdxList{blob}(end))],[-0.12 -0.12],'color',[.5 .5 .5],'linewidth',7);
    end


    %% X1 
      plotclust = bwconncomp(X1_cluster,conn);
    for blob=1:plotclust.NumObjects;
        plot([tftime(plotclust.PixelIdxList{blob}(1)) tftime(plotclust.PixelIdxList{blob}(end))],[-0.13 -0.13],'color',color_map(line_1_number,:),'linewidth',7);
    end

    %% X2
    plotclust = bwconncomp(X2_cluster,conn);
    for blob=1:plotclust.NumObjects;
        plot([tftime(plotclust.PixelIdxList{blob}(1)) tftime(plotclust.PixelIdxList{blob}(end))],[-0.14 -0.14],'color',color_map(line_2_number,:),'linewidth',7);
    end

