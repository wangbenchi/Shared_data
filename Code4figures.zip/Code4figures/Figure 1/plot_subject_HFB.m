clc,clear


subject_file = dir('*.mat')
condition = 'all trial dis'

ele_folder = 'J:\SL整理\HBF ele\激活\Z score\60-100 Hz FDR\0-1500 ms(18个病人 剔除病灶，保留白质）';

subject_HFB=[];
for id = 1:length(subject_file)
    name = subject_file(id).name;
  

    if strcmpi(condition,'only tar')
            subject_name = name(1:end-51);
            ele_path = [ ele_folder '\only tar' filesep subject_name '_positive_only tar_ele_Z'];
    else
        subject_name = name(1:end-54);
        ele_path = [ ele_folder '\mixed dis none' filesep subject_name '_positive_mixed dis_ele_Z'];
    end

     ele_path = [ ele_folder '\mixed dis none' filesep subject_name '_positive_mixed dis_ele_Z'];
     load(name)
     load(ele_path)

      ele_labels ={dim.chans.labels};
         %ele_labels = dim.chans;
        real_ele_index = [];
        for i =1:length(real_ele_all)
         
            ele_name = real_ele_all{i};
            real_ele_index(i) = find(strcmpi(ele_labels,ele_name));
        end
        location_data=[];
        for location = 1:8
            location_data = cat(3,location_data,fre_power{location});
        end
        subject_HFB(id,:) = squeeze(mean(mean(location_data(real_ele_index,:,:),1),3));



end









subject_HFB_with_IED = subject_HFB;

subject_HFB_only_IED = subject_HFB;

subject_HFB_without_IED = subject_HFB;


data_folder ='L:\with and without IED HFB';

data_path = [data_folder filesep 'HFB_data' ]

save(data_path,'subject_HFB_with_IED','subject_HFB_only_IED','subject_HFB_without_IED','dim','-v7.3')


subject_index = [1:18];
subject_index([2,8,9,11])=[];
base_time_index = dsearchn(dim.times',[-400 -100]');
only_IED_base = squeeze(mean(subject_HFB_only_IED(:,base_time_index(1):base_time_index(end)),2));
with_IED_base = squeeze(mean(subject_HFB_with_IED(:,base_time_index(1):base_time_index(end)),2));
without_IED_base = squeeze(mean(subject_HFB_without_IED(:,base_time_index(1):base_time_index(end)),2));

only_HFB_increase = subject_HFB_only_IED - only_IED_base;
with_HFB_increase = subject_HFB_with_IED - with_IED_base;
without_HFB_increase = subject_HFB_without_IED - without_IED_base;


only_IED_mean = squeeze(nanmean(only_HFB_increase(subject_index,:),1));
with_IED_mean = squeeze(nanmean(with_HFB_increase(subject_index,:),1));
without_IED_mean = squeeze(nanmean(without_HFB_increase(subject_index,:),1));

nSubjects = length(subject_index);
X1 = only_HFB_increase(subject_index,:);
X2 = with_HFB_increase(subject_index,:);
X3 = without_HFB_increase(subject_index,:);

 color_map=[
      19,107,28;
     255,77,255;
     241,136,101;
     107,170,201;
       66 34 86]/256;
list_number = [1 4];
line_1_data = 1.044;
line_2_data = 1.460;
line_1_number = 1;
line_2_number = 3;
line_3_number = 4;
tftime = dim.times;
fontsize = 46;
figure('position',[1,1,1340,800]), clf
set(gca,'FontSize',fontsize)
[l,p] = boundedline(tftime,squeeze(mean(X1)),squeeze(std(X1))./sqrt(nSubjects),'cmap',color_map(line_1_number,:),'alpha','transparency',.3);
h(1)=l;
[l,p] = boundedline(tftime,squeeze(mean(X2)),squeeze(std(X2))./sqrt(nSubjects),'cmap',color_map(line_2_number,:),'alpha','transparency',.3);
h(2)=l;
[l,p] = boundedline(tftime,squeeze(mean(X3)),squeeze(std(X3))./sqrt(nSubjects),'cmap',color_map(line_3_number,:),'alpha','transparency',.3);
h(3)=l;
hold on;
plot(tftime,squeeze(mean(X1)),'Color',color_map(line_1_number,:),'LineWidth',7);hold on
plot(tftime,squeeze(mean(X2)),'Color',color_map(line_2_number,:),'LineWidth',7);hold on
plot(tftime,squeeze(mean(X3)),'Color',color_map(line_3_number,:),'LineWidth',7);hold on
% legend('Only','with','without')
% set(legend,'AutoUpdate','off')



yl=get(gca,'ylim');
ax = gca;
ax.YLim = [-0.1 0.25];
ax.XLim = [-500 4000];
ax.LineWidth = 4;
set(gca,'XTick',[-0:1000:4000])
yl=get(gca,'ylim');
set(gca,'YTick',[ -0.2 -0.1 0  0.1 0.2])

set(gca,'TickDir','out')







