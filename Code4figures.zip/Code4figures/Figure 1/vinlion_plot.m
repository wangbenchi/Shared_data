clc,clear
addpath('\\Desktop-nsg699e\j\code\Violinplot-Matlab-master')
mixed_tar = mixed_tar*1000;
mixed_dis = mixed_dis*1000;
only_tar = only_tar*1000;
%all_trial_dis = all_trial_dis*1000;

only_tar_labels = repmat({'Tar.only'},[1,18])';
%all_trial_dis_labels = repmat({'mixed-search'},[1,18])';

mixed_dis_labels = repmat({'Dis.present'},[1,18])';
midex_tar_labels = repmat({'Dis.absent'},[1,18])';


colormap = round(100*[224 234 247;
                    48 129 191; ...
                     16 55 120]/255)/100;
 %colormap={'#ff00ff';'#EC8D5F';'#0BB1D9'};
 colormap={'#0BB1D9';'#EC8D5F';'#ff00ff'};

 color_map=[
     255,77,255;
     19,107,28;
     236,83,95;
     11,118,217;
     %241,136,101;
     %107,170,201;
       66 34 86;
242,139,48]/256;

 RGB = validatecolor(colormap,'multiple');
 all_data=[];
 all_labels={};

%all_data = cat(1,mixed_tar,mixed_dis,only_tar);

all_data = cat(1,only_tar,mixed_tar,mixed_dis);
all_labels = cat(1,only_tar_labels,mixed_dis_labels,midex_tar_labels);

%all_data = cat(1,mixed_dis,mixed_tar);
% all_data = cat(1,mixed_tar,mixed_dis);
% all_labels = cat(1,mixed_dis_labels,midex_tar_labels);
% 
% all_data = cat(1,only_tar,all_trial_dis);
% all_labels = cat(1,only_tar_labels,all_trial_dis_labels);
    fontsize = 38;
    dotsize = 30;
 %figure('Position',[1 1 900 800])
figure('Position',[1 1 1100 800])
 set(gca,'LooseInset',get(gca,'TightInset'))  %ȥ����
vs = violinplot(all_data, all_labels);hold on

only_tar_std = std(only_tar);
only_tar_mean = mean(only_tar);
% 
% all_trial_dis_std = std(all_trial_dis);
% all_trial_dis_mean = mean(all_trial_dis);
% 
mixed_tar_mean = mean(mixed_tar);
mixed_tar_std = std(mixed_tar);

mixed_dis_mean = mean(mixed_dis);
mixed_dis_std = std(mixed_dis);

 all_mean = [mixed_dis_mean,mixed_tar_mean,only_tar_mean];
% all_std = [mixed_tar_std mixed_dis_std]/sqrt(9);

x_data=[];
y_data=[];
x_list =[1,2,3];
for i = 1:3
    vs(1, i).ViolinPlot.FaceColor = colormap{i};
    %vs(1, i).ViolinPlot.FaceColor = color_map(i,:);
     vs(1, i).ViolinPlot.EdgeColor = [1,1,1];
    x_data(i,:) = vs(1, i).ScatterPlot.XData;
    y_data(i,:) =vs(1, i).ScatterPlot.YData;
   
   vs(1,i).ScatterPlot.MarkerFaceColor = colormap{i};
    %vs(1,i).ScatterPlot.MarkerFaceColor = color_map(i,:);
    vs(1,i).ScatterPlot.SizeData = 80;
    %vs(1,i).ScatterPlot.MarkerFaceAlpha = 0;
    vs(1, i).BoxPlot.FaceColor = colormap{i};
    %vs(1, i).BoxPlot.FaceColor = color_map(i,:);
    vs(1, i).MedianPlot.MarkerFaceColor = [0,0,0];
    vs(1, i).MedianPlot.Marker = 's';
    vs(1, i).MedianPlot.SizeData = 60;

    


end

for n = 1:18
L = line(x_data(1:2,n),y_data(1:2,n));hold on
L.LineStyle = '-';
L.LineWidth = 2;
L.Color = [0.5,0.5,0.5];

L = line(x_data(2:3,n),y_data(2:3,n));hold on
L.LineStyle = '-';
L.LineWidth = 2;
L.Color = [0.5,0.5,0.5];
end
% x_list =[1,2];
% L = line(x_list,all_mean);hold on
% L.LineStyle = '--';
% L.LineWidth = 3;
% L.Color = 'k';
Meandot = scatter(x_list,all_mean,'d');hold on
Meandot.MarkerEdgeColor = [0.5,0.5,0.5]
Meandot.LineWidth=5;
CF = gca;
CF.XTickLabel = {'Dis. present','Dis. absent','Tar.only'};
%CF.XTickLabel = {'Tar.only','Dis. absent','Dis. present'};
set(gca,'Ylim',[500 2600]);
  set(gca,'yTick',[600:400:2200]);
    set(gca,'LineWidth',6,'xcolor','k','ycolor','k')
      ylabel('Response time (ms)','FontSize',42)
     %�ѿ̶��߳���c
    set(gca,'tickdir','out')
    %ȥ��������ұߵĿ�
    set(gca,'Box','off')
    %xlabel('High probability')
    %�ı������������ʹ�С
    set(gca,'FontSize',fontsize);%'Fontname', 'Times New Roman'
    