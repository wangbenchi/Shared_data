clc,clear
subject_file = dir('*.mat')
subject_number = 1
condition = 'all trial dis'
behave_folder = ['J:\SL����\behave\sort RT trial\Z score'];
ele_folder = ['J:\SL����\HBF ele\����\Z score\60-100 Hz FDR\0-1500 ms(18������ �޳�����������ʣ�\'];
%ele_folder =['J:\SL����\HBF ele\����\Z score prob and non prob\FDR time control']
resnpose_atlas = {'bone','unknown'};
prob_condition = 'non prob';
% [NUM,TXT,RAW]=xlsread('F:\\DK atlas.xlsx',2);
% atlas_subject_info = RAW(:,5);
% atlas_subject_info = strrep(atlas_subject_info,'''','');
% all_subject_network_infro=[];
for id = 1:length(subject_file)
    clear EEGb subject_name real_ele_all onli_dis_ele only_dis_ele dis_sort_index dis_sort_data 
    clear fre_power fre_power_60_140_Hz fre_power_alpha
    name = subject_file(id).name;
    load(name)
    %subject_name = name;
    if strcmpi(condition,'only tar')
        subject_name = name(1:end-51);
        ele_path = [ele_folder '\only tar' filesep subject_name '_positive_only tar_ele_Z'];
    else
        subject_name = name(1:end-70);
        ele_path = [ele_folder '\mixed dis none' filesep subject_name '_positive_mixed dis_ele_Z'];
    end
      load(ele_path)
%     subject_index = find(strcmpi(atlas_subject_info,subject_name));
%     subejct_atlas = RAW(subject_index,10);      
%     subejct_atlas =  strrep(subejct_atlas,'''','');
%     subejct_atlas_ele = RAW(subject_index,2);  
%     subject_atals_info = RAW(subject_index,:);     
%     subejct_atlas_hel = RAW(subject_index,4);   
%     response_atlas_index = find(~ismember(subejct_atlas,resnpose_atlas));
% 
% 
%     response_atlas = subejct_atlas(response_atlas_index);
%     response_hel = subejct_atlas_hel(response_atlas_index);
%     subject_atals_info = subject_atals_info(response_atlas_index,10);
%     all_subject_network_infro = [all_subject_network_infro;subject_atals_info]; 
% 
%     real_ele_all = subejct_atlas_ele(response_atlas_index);
%     response_hel = strrep(response_hel,'''','');
%     ele_labels = {dim.chans.labels};
%     all_ele = [1:length(ele_labels)];
%     ele_index = [];
%     for i =1:length(real_ele_all)
%         ele_hel = response_hel{i};
%         ele_name = real_ele_all{i};
%         ele_name(end)=[];
%         if strcmpi(ele_hel,'R')
%             ele_name = strrep(ele_name,'''''','''');
%         end
%         ele_index(i) = find(strcmpi(ele_labels,ele_name));
%     end
%       
      
    dis_labels = {dim.chans.labels};
    ele_index=[];
    for i = 1:length(real_ele_all)
        ele_name = real_ele_all{i};
        ele_index(i) = find(strcmpi(dis_labels,ele_name));
    end

    if strcmpi(condition,'mixed dis')
        sort_data_path = [ behave_folder '\mixed dis\' prob_condition filesep subject_name '_sort_index_dis'];
    elseif strcmpi(condition,'mixed tar')
        sort_data_path = [ behave_folder '\mixed tar\' prob_condition filesep subject_name '_sort_index_mixed_tar'];
    elseif strcmpi(condition,'all trial dis')
        sort_data_path = [ behave_folder '\all trial dis\' prob_condition filesep subject_name '_sort_index_all_trial_dis'];  
    elseif strcmpi(condition,'only tar')
        sort_data_path = [ behave_folder '\only tar' filesep subject_name '_sort_index_only_tar'];  
    elseif strcmpi(condition,'high')
        sort_data_path = [ behave_folder '\high and low' filesep 'high' filesep  subject_name '_sort_index_dis'];  
     elseif strcmpi(condition,'low')
        sort_data_path = [ behave_folder '\high and low' filesep 'low' filesep subject_name '_sort_index_dis'];  
    end
    load(sort_data_path)
 
    
    for i = 1:length(dis_sort_index)
        location = dis_sort_index_location(i);
        key = dis_sort_index(i);
        


        try
           eval(['dis_sort_data(:,:,' num2str(i) ') =fre_power_beta{' num2str(location) '}(:,:,' num2str(key) ');']);
        catch
            eval(['dis_sort_data(:,:,' num2str(i) ') =fre_power{' num2str(location) '}(:,:,' num2str(key) ');']);
        end
    end

    %% mixed tar
    if strcmpi(condition,'mixed dis')  
        subject_all_RT_mixed_dis(subject_number,:)  = dis_RT;
        subject_dis_data_sort(subject_number,:,:) = squeeze(mean(dis_sort_data(ele_index,:,:),1));
        subject_dis_data_sort_all_ele(subject_number,:,:) = squeeze(mean(dis_sort_data(:,:,:)));
    elseif strcmpi(condition,'mixed tar')
          subject_all_RT_mixed_tar(subject_number,:)  = dis_RT;
        subject_mixed_tar_data_sort(subject_number,:,:) = squeeze(mean(dis_sort_data(ele_index,:,:),1));
        subject_mixed_tar_data_sort_all_ele(subject_number,:,:) = squeeze(mean(dis_sort_data(:,:,:)));
    elseif strcmpi(condition,'all trial dis')
         subject_all_RT_all_trial_dis(subject_number,:)  = dis_RT;
        subject_all_trial_dis_data_sort(subject_number,:,:) = squeeze(mean(dis_sort_data(ele_index,:,:),1));
        subject_all_trial_dis_data_sort_all_ele(subject_number,:,:) = squeeze(mean(dis_sort_data(:,:,:)));
    elseif strcmpi(condition,'only tar')
        subject_all_RT_only_tar(subject_number,:)  = dis_RT;
        subject_tar_data_sort(subject_number,:,:) = squeeze(mean(dis_sort_data(ele_index,:,:),1));
        subject_tar_data_sort_all_ele(subject_number,:,:) = squeeze(mean(dis_sort_data(:,:,:)));
        
    elseif strcmpi(condition,'high')
        subject_all_RT_high(subject_number,:)  = dis_RT;
        subject_tar_data_sort(subject_number,:,:) = squeeze(mean(dis_sort_data(ele_index,:,:),1));
 
   elseif strcmpi(condition,'low')
        subject_all_RT_low(subject_number,:)  = dis_RT;
        subject_tar_data_sort(subject_number,:,:) = squeeze(mean(dis_sort_data(ele_index,:,:),1));
    
        
    end
   
    subject_number = subject_number+1;
    
    
end




all_RT_mean = mean(all_RT,3);
all_data_mean = mean(all_data,4);


if strcmpi(condition,'mixed dis')
    subject_dis_data_sort = permute(subject_dis_data_sort,[1,3,2]);
    subject_dis_data_sort_all_ele = permute(subject_dis_data_sort_all_ele,[1,3,2]);
elseif strcmpi(condition,'mixed tar')
    subject_dis_data_sort = permute(subject_mixed_tar_data_sort,[1,3,2]);
    subject_dis_data_sort_all_ele = permute(subject_mixed_tar_data_sort_all_ele,[1,3,2]);
elseif strcmpi(condition,'all trial dis')
    subject_dis_data_sort = permute(subject_all_trial_dis_data_sort,[1,3,2]);
    subject_dis_data_sort_all_ele = permute(subject_all_trial_dis_data_sort_all_ele,[1,3,2]);
elseif strcmpi(condition,'only tar')
    subject_dis_data_sort = permute(subject_tar_data_sort,[1,3,2]);
    subject_dis_data_sort_all_ele = permute(subject_tar_data_sort_all_ele,[1,3,2]);
    
elseif strcmpi(condition,'high')
    subject_dis_data_sort = permute(subject_tar_data_sort,[1,3,2]);

elseif strcmpi(condition,'low')
    subject_dis_data_sort = permute(subject_tar_data_sort,[1,3,2]);

end

%% mean
subject_all_RT_mean = mean(subject_all_RT_all_trial_dis);
subject_dis_data_sort_mean = squeeze(mean(subject_dis_data_sort));
subject_dis_data_sort_mean_all_ele = squeeze(mean(subject_dis_data_sort_all_ele));
%% base correct
base = [-400 -100];
base_time = dsearchn(dim.times',base');
base_data = mean(subject_dis_data_sort_mean(:,base_time(1):base_time(end)),2);
base_data_all_ele = mean(subject_dis_data_sort_mean_all_ele(:,base_time(1):base_time(end)),2);

% dis_sort_data_increase = subject_dis_data_sort_mean-base_data;
% dis_sort_data_increase_all_ele = subject_dis_data_sort_mean_all_ele-base_data_all_ele;

dis_sort_data_increase = subject_dis_data_sort_mean;
dis_sort_data_increase_all_ele = subject_dis_data_sort_mean_all_ele;

eopch_time = dsearchn(dim.times',[-500 4000]');

max_index_region_ele=[];
max_index_all_ele=[];
%% density
trial_number = [1:size(dis_sort_data_increase,1)];
% trial_index = find(subject_all_RT_mean>2);
% trial_number(trial_index)=[];

for i = 1:length(trial_number)
 
    density_time = [0 4000];
    density_time_index = dsearchn(dim.times',density_time');
 
    [max_region_ele_data,max_index_region_ele_index] =  max(dis_sort_data_increase(i,density_time_index(1):density_time_index(end)));
    %[max_all_ele_data,max_index_all_ele_index] =  max(dis_sort_data_increase_all_ele(i,density_time_index(1):density_time_index(end)));
    
    max_index_time = dim.times(density_time_index(1):density_time_index(end));
    max_index_region_ele(i) = max_index_time(max_index_region_ele_index);
    %max_index_all_ele(i) = max_index_time(max_index_all_ele_index);
    
    %max_data_all_ele(i) = max_all_ele_data;
    max_data_region_ele(i) = max_region_ele_data;
end
median_RT_peak = median(max_index_region_ele);
median_RT_peak_all_ele = median(max_index_all_ele);

% 
% trial_index = find(max_index_region_ele>2000);
% trial_number(trial_index)=[];
% dis_sort_data_increase_try = dis_sort_data_increase;
% for i = 1:length(trial_number)
% trial_time_index(i) = dsearchn(dim.times',subject_all_RT_mean(i)*1000);
% dis_sort_data_increase_try(i,trial_time_index(i)+1:end)=-0.1;
% end

map=round(100*[23,77,134;
27,87,158;
42,122,184;
52,136,191;
66,146,195;
109,175,209;
159, 203,225;
247,251,253;
252,203,176;
243,166,131;
232,133,102;
211,89,72;
176,31,44;
124,18,34]/255)/100;

%% region ele
fontsize = 44;
F = figure('Position',[1,1,1440,800])
% map = mymap('viridis')
%colormap(F,map)

%%  ��ɫ
[~, real_obj] = contourf(dim.times(eopch_time(1):eopch_time(end)),[1:length(trial_number)],dis_sort_data_increase(trial_number,eopch_time(1):eopch_time(end)),'linecolor','none');hold on
contourFillObjs = real_obj.FacePrims;
for i = 1:length(contourFillObjs)
    % Have to set this. The default is 'truecolor' which ignores alpha.
    contourFillObjs(i).ColorType = 'truecoloralpha';
    % The 4th element is the 'alpha' value. First 3 are RGB. Note, the
    % values expected are in range 0-255.
    contourFillObjs(i).ColorData(4) = 270;
end
plot(subject_all_RT_mean(trial_number)*1000,[1:length(trial_number)],'r','LineWidth',8);hold on
%scatter(max_index_region_ele(trial_number),[1:length(trial_number)],'r');hold on
set(gca,'FontSize',fontsize)

line([180 180],[1 length(trial_number)],'Color','r','LineWidth',8,'LineStyle',':');
%text(median_RT_peak,length(trial_number)+45,['median Latancy peak is ' num2str(median_RT_peak) 'ms'],'FontSize',18)
ylabel('Trials','FontSize',fontsize)
xlabel('Time (ms)','FontSize',fontsize)
yl = get(gca,'clim');
set(gca,'clim',[-0.3 0.3])
%title('Mixed design','FontSize',36)
H = colorbar();
H.Ticks = [-0.3 -0.15,0,0.15 0.3];
ax = gca;
%ax.YLim = [0 680];
ax.XLim = [-500 4000];
%ax.LineWidth = 3;
set(gca,'XTick',[-0:1000:4000])
set(gca,'YTick',[0 300 720])


%% all ele
fontsize=36
figure('Position',[1,1,2440,1080])
contourf(dim.times(eopch_time(1):eopch_time(end)),[1:size(dis_sort_data_increase_all_ele,1)],dis_sort_data_increase_all_ele(:,eopch_time(1):eopch_time(end)),'linecolor','none');hold on
plot(subject_all_RT_mean*1000,[1:size(dis_sort_data_increase_all_ele,1)],'r');hold on
scatter(max_index_region_ele,[1:size(dis_sort_data_increase_all_ele,1)],'r');hold on
line([median_RT_peak_all_ele median_RT_peak_all_ele],[1 size(dis_sort_data_increase_all_ele,1)],'Color','r','LineWidth',5);
text(median_RT_peak_all_ele,size(dis_sort_data_increase_all_ele,1)+30,['median RT peak is ' num2str(median_RT_peak_all_ele) 'ms'],'FontSize',fontsize)
ylabel('Trials','FontSize',fontsize)
xlabel('time (ms)','FontSize',fontsize)
yl = get(gca,'clim');
set(gca,'clim',[-mean(yl) mean(yl)])
title('only tar condition gamma Z all ele','FontSize',fontsize)
colorbar()


wsize=4;
trial_density_smooth = nanfastsmooth(trial_density,wsize,2,0.5); 
figure('Position',[1,1,2440,1080])
plot(trial_density_smooth)
ylabel('db density','FontSize',fontsize)
xlabel('time trials','FontSize',fontsize)
yl = get(gca,'ylim');
set(gca,'ylim',[min(yl) 0]);
title('Distractor condition alpha','FontSize',fontsize)
%% corr
power_mean = squeeze(mean(dis_sort_data_increase));

x_region = max_index_region_ele(trial_number)';
% x_all_ele = max_index_all_ele(trial_number)';
y = subject_all_RT_mean(trial_number)'*1000;
 [coef, pval] = corr(x_region, y)
 [coef, pval] = corr(x_all_ele, y)

x_data_all_ele = max_data_all_ele';
x_data_regione_ele = max_index_region_ele';
y = subject_all_RT_mean'*1000;
 [coef, pval] = corr(x_data_all_ele, y)
 [coef, pval] = corr(x_data_regione_ele, y)
figure('Position',[1,1,2440,1080])
scatter(y,x_region)
ylabel('time peak','FontSize',fontsize)
xlabel('RT','FontSize',fontsize)
title('mixed tar condition alpha','FontSize',fontsize)

x_region = [1:size(dis_sort_data_increase,1)];

[p,S,mu] = polyfit(x_region,trial_density,1)
[y, delta] = polyval(p,x_region,S,mu);
plot(y)