
%
% Calculate CTF slopes for real and permuted data
% һ�����������ģ�һ���Ǹ���λ�÷����
% updated: fixed the unecessary dimension in slope matrix



%subject_name = 'hongxiaoxuan_non_prob_only_tar_pre'
CTF_data_folder = [data_folder filesep  'CTF' filesep condition];
if ~exist(CTF_data_folder)
    mkdir(CTF_data_folder)
end

if ~strcmpi(prob_condition,'prob')
    rDat.evoked = squeeze(mean(mean(em.tar.mean_evoked,2),4));
    pDat.evoked = squeeze(mean(em.permtfs.mean_location,2));
    % Specify properties
    nChans = em.nChans; % # of location channels
    nPerms = 1000; % % of permutations
    nSamps = length(em.time); % # of samples
    nFreqs = 1; % # of frequencies

    % preallocate arrays for slope values
    rSl.evoked = nan(nSamps,1); rSl.total = rSl.evoked;
    pSl.evoked = nan(nSamps,nPerms); pSl.total = pSl.evoked;

    % real evoked data
    % ����б��

    for samp = 1:nSamps;
        dat = squeeze(rDat.evoked(samp,:));
        x = 1:5;
        d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
        fit = polyfit(x,d,1);
        rSl.evoked(samp)= fit(1) ;
    end

    % permuted evoked data
    for perm = 1:nPerms
        for samp = 1:nSamps;
            dat = squeeze(pDat.evoked(perm,samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            pSl.evoked(samp,perm)= fit(1) ;
        end
    end
else
    rDat.evoked_high = squeeze(mean(mean(em.tar.evoked_high,2),4));
    rDat.evoked_low = squeeze(mean(mean(em.tar.evoked_low,2),4));
    rDat.evoked_random = squeeze(mean(mean(em.tar.evoked_random,2),4));
    rDat.evoked = squeeze(mean(mean(em.tar.mean_evoked,2),4));
    
    pDat.evoked = squeeze(mean(em.permtfs.mean_location,2));
    pDat.evoked_high = squeeze(mean(em.permtfs.mean_location_high,2));
    pDat.evoked_low = squeeze(mean(em.permtfs.mean_location_low,2));
    pDat.evoked_random = squeeze(mean(em.permtfs.mean_location_random,2));
    %% real
    
    nSamps = length(em.time);
        for samp = 1:nSamps
            dat = squeeze(rDat.evoked(samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            rSl.evoked(samp)= fit(1) ;
        end
        for samp = 1:nSamps
            %% high
            dat = squeeze(rDat.evoked_high(samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            rSl.evoked_high(samp)= fit(1) ;

            %% low
            dat = squeeze(rDat.evoked_low(samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            rSl.evoked_low(samp)= fit(1) ;
               %% low
            dat = squeeze(rDat.evoked_random(samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            rSl.evoked_random(samp)= fit(1) ;
        end
    %% permutation
     % permuted evoked data
    for perm = 1:nPerms
        for samp = 1:nSamps;
            dat = squeeze(pDat.evoked(perm,samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            pSl.evoked(samp,perm)= fit(1) ;
        end
    end
    
     for perm = 1:nPerms
        for samp = 1:nSamps;
            dat = squeeze(pDat.evoked_high(perm,samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            pSl.evoked_high(samp,perm)= fit(1) ;
            
            
            dat = squeeze(pDat.evoked_low(perm,samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            pSl.evoked_low(samp,perm)= fit(1) ;
            
            dat = squeeze(pDat.evoked_random(perm,samp,:));
            x = 1:5;
            d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
            fit = polyfit(x,d,1);
            pSl.evoked_random(samp,perm)= fit(1) ;
            
       
            
        end
    end
    
end

filename = [CTF_data_folder filesep subject_name '_CTFslopes.mat'];
save(filename,'subject_name','rSl','pSl','-v7.3');
% save slope matrices
% filename = ['K:\wang\SL\IEM\Z score\CTF\60-100 Hz\' subject_name '_CTFslopes.mat'];
% save(filename,'subject_name','rSl','pSl','-v7.3');
clc,clear
