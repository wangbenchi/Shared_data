clc,clear
%close all
condition_dir = dir()
%condition_list = {'mixed dis','mixed tar dis'};
condition_list = {'with','without'};
%condition_list = {'all trial dis','only tar'};
%condition_list = {'diff'};
% condition_list = {'fast','slow'};
line_number = [8 9]      
%  color_map=[
%      235,104,107
%      5,61,56;
%      242,29,7;
%      0,75,141;
%      %241,136,101;
%      %107,170,201;
%        66 34 86;
%    107,170,201]/256;


% 
%color_map =[241,65,107;87,185,0;66 34 86;66 34 86;66 34 86;66 34 86;]/256
 color_map=[
     19,107,28;
     255,77,255;
     236,83,95;
     11,118,217;
     %241,136,101;
     %107,170,201;
       66 34 86;
242,139,48;
1,127,139;
239,133,100;
107,168,199]/256;
list_number = [3 4];
for i = 1:length(condition_dir)-2
    if i ==1
        condition = condition_dir(i+2).name;
        data_fame = dir(fullfile(condition,'*.mat'))
        for x = 1:2
           
          if x ==1
                load([condition filesep condition_list{1}])
                dis_seAverage = seAverage;
                dis_draw = draw;
                dis_subAverage = subAverage;
                 dis_boot = boot;
                clear seAverage draw subAverage boot
          else
            
                load([condition filesep condition_list{2}])
                tar_seAverage = seAverage;
                tar_draw = draw;
                tar_subAverage = subAverage;
                 tar_boot = boot;
                clear seAverage draw subAverage boot
            end
        end
     elseif i ==2
        load(['diff' filesep condition_list{1} '-' condition_list{2} '_diff_permutation'])
         
   
    end
      
end
%% plot significant clusters



%tm = [-2500:20:7500];;
%tm = [-500:2:1500];
Ntp = length(tm);
% cluster
bLine = zeros(1,Ntp);

dis_sig = ones(1,length(dis_draw))*0.14;
%dis_sig = 0.13
tar_sig = ones(1,length(tar_draw))*0.15;
% %tar_sig = 0.135;
diff_number = length(find(logical(diff_cluster)));
diff_time = tm(logical(diff_cluster));
diff_sig = ones(1,diff_number)*0.15;
%diff_sig(logical(diff_cluster)) = 0.09;

%% no cluster
diff_number_no_cluster = length(find(logical(diff_tmapthresh)));
diff_time_no_cluster = tm(logical(diff_tmapthresh));
diff_sig_no_cluster = ones(1,diff_number_no_cluster)*0.06;




diff = dis_subAverage - tar_subAverage;

fontsize = 30; % size for axis numbers
labelSize = 30; % size for axis labels
dotsize = 250;
handle.fig2=figure('units','normalize','position',[0.1  0.1 0.3 0.7],...
                                     'color',[1 1 1],'Name','Bulletin Figure');       
%    handle.fig2=figure('units','normalize','position',[0.1  0.1 0.6 0.7],...
%                                      'color',[1 1 1],'Name','Bulletin Figure');        
%                                  
%  handle.fig2=figure('units','normalize','position',[0.1  0.1 0.35 0.48],...
%                                      'color',[1 1 1],'Name','Bulletin Figure');                                       
handle.diff_score =  axes('Parent',handle.fig2,...
        'Units','normalized','Position',[0.20    0.45    0.7    0.5]);   
plot(tm,dis_subAverage,'Color',color_map(line_number(1),:),'LineWidth',6);hold on
plot(tm,tar_subAverage,'Color',color_map(line_number(2),:),'LineWidth',6);hold on
% 
Dis_shade = shadedErrorBar(tm,dis_subAverage,dis_sem);hold on
Tar_shade = shadedErrorBar(tm,tar_subAverage,tar_sem);hold on


%Dis_shade.patch.EdgeColor = color_map(line_number(1),:);
Dis_shade.patch.FaceColor  = color_map(line_number(1),:);
Dis_shade.mainLine.Color = color_map(line_number(1),:);

Tar_shade.patch.FaceColor  = color_map(line_number(2),:);
Tar_shade.mainLine.Color  = color_map(line_number(2),:);
Tar_shade.mainLine.Color  = color_map(line_number(2),:);


Dis_shade.edge(1).Visible = 'off';
Dis_shade.edge(2).Visible = 'off';
Tar_shade.edge(1).Visible = 'off';
Tar_shade.edge(2).Visible = 'off';
% scatter(data_1_CTF_half_time,dis_subAverage(data_1_CTF_index),'filled','MarkerEdgeColor',color_map(line_number(1),:),'MarkerFaceColor',color_map(line_number(1),:),'MarkerFaceAlpha',1,'SizeData',dotsize);hold on
% scatter(data_2_CTF_half_time,tar_subAverage(data_2_CTF_index),'filled','MarkerEdgeColor',color_map(line_number(2),:),'MarkerFaceColor',color_map(line_number(2),:),'MarkerFaceAlpha',1,'SizeData',dotsize);hold on
% 
%L = legend('Positive region','Negative region');
%L = legend('Mixed search','Target-only search');
% L = legend('Target location (Dis. present)','Target location (Dis. absent)');
%L = legend('High location (Dis. present)','Low location (Dis. present)');
L.EdgeColor = [1,1,1];
L.FontSize= 30;
L.Position= [0.46 0.87 0.3 0.1];
L.Position= [0.32 0.9 0.3 0.1];
scatter(tm(dis_draw),dis_sig,2,color_map(line_number(1),:),'filled','SizeData',60)
scatter(tm(tar_draw),tar_sig,2,color_map(line_number(2),:),'filled','SizeData',60)
%legend('Target location (fast)','Target location (slow)');
data = tm(dis_draw);
plot(tm,bLine,'Color',[0.5 0.5 0.5],'LineWidth',2,'Linestyle','--');
ax = gca;
ax.YLim = [-0.05 0.2];
yl=get(gca,'ylim');
ax.XLim = [-0 1000];
set(gca,'XTick',[-0:200:1000])
set(gca,'XTicklabels',[])
set(gca,'YTick',[ 0  0.1 0.2])
set(gca, 'box','off')
set(gca,'color','none')
set(gca,'LineWidth',1,'TickDir','out');
set(gca,'FontSize',fontsize)
set(gca,'FontName','Arial')
%xlabel('Time (ms)','FontSize',fontsize);
%ylabel('Gamma CTF slope','FontSize',fontsize)
ylabel('Gamma CTF slope','FontSize',42)
ax.LineWidth = 4;
% % 
bLine = ones(1,Ntp)*0;
handle.T_score =  axes('Parent',handle.fig2,...
        'Units','norm alized','Position',[0.2    0.245    0.7    0.15]);  
H =plot(tm,diff,'Color',color_map(5,:),'LineWidth',4);hold on
plot(tm,bLine,'Color',[0.5 0.5 0.5],'LineWidth',4,'Linestyle','--');
Dis_shade = shadedErrorBar(tm,diff,diff_sem);hold on

scatter(tm(find(logical(diff_cluster))),diff_sig,2,color_map(5,:),'filled','SizeData',60)
%scatter(tm(find(logical(diff_tmapthresh))),diff_sig_no_cluster,2,color_map(6,:),'filled','SizeData',30)
%text(160,0.12,'Un-corrected','FontSize',34) 
ax = gca;
ax.YLim = [-0.1 0.15];
yl=get(gca,'ylim');
ax.XLim = [0 1000];
set(gca,'XTick',[-0:200:1000])
set(gca,'YTick',[-0.15  0  0.15])
set(gca, 'box','off')
set(gca,'color','none')
set(gca,'LineWidth',1,'TickDir','out');
set(gca,'FontSize',fontsize)
set(gca,'FontName','Arial')
%xlabel('Time (ms)','FontSize',fontsize);
%ylabel('Gamma CTF slope','FontSize',fontsize)
ylabel('Diff. value','FontSize',42)
ax.LineWidth = 4;
