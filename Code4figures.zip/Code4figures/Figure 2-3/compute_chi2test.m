clc,clear
real_CTF = CTF_infor(:,1);
real_CTF_mean = mean(real_CTF);
real_CTF_median = median(real_CTF);





subejct_file = dir('*.mat');
for id = 1:length(subejct_file)
    name = subejct_file(id).name;
    load(name);
    atlas_name = name(1:end-4);
    atals_CTF = CTF_infor(:,1);
    atals_CTF_mean = mean(atals_CTF);
    atals_CTF_median = median(atals_CTF);
    atlas_CTF_bin=[];
%      for n = 1:100
%          atlas_CTF_bin(n) = mean(atals_CTF(1+10*(n-1):10*n));
%      end
     
%      number_list = [1:1000];
%      number_list = shuffle(number_list);
%      real_list = [1:1000];
%      real_list = shuffle(real_list);
%      
%      [coef, pval] = corr(x, y,'type','Spearman')
%      p,h = corr(x,y)
     
%     [h,t_p,ci,stats] =ttest2(atals_CTF(number_list(1:100)),real_CTF(real_list(1:100)));
    %[h,chip,~,stats]=vartest2(real_CTF,atals_CTF);
    [h,chip,test,df]=chi2test2(atals_CTF,real_CTF,0.05,50);
    %[h,chip]=chi2test2(atals_CTF,real_CTF,0.01);
    %[h,chip] = chi2test2(real_CTF,atals_CTF)

  
    
%     
    %[rankP]=ranksum_U(real_CTF,atals_CTF);
    %[p,h] = signrank(real_CTF,atals_CTF)

%     [H, pValue, KSstatistic]=kstest2(atals_CTF,real_CTF)
    % [~, chi2, chip, labels] =crosstab(real_CTF,atals_CTF);

    %atlas_info(id).wmtest = rankP;
    atlas_info(id).chip = chip;
    atlas_info(id).test = test;
    atlas_info(id).df = df;
    atlas_info(id).mean_data = atals_CTF_mean;
    atlas_info(id).median_data = atals_CTF_median;
    % atlas_info(id).mean_CTF = atlas_CTF_mean;
    %atlas_info(id).kstest = pValue;
    %atlas_info(id).t_p=t_p;
    atlas_info(id).name = atlas_name;
end


chip = cell2mat({atlas_info.chip});
chip = chip';
index = [2,8,9,13,19];
chip(index)=[];
[p_fdr, p_masked]=fdr(chip,0.05);

p_masked = p_masked';
