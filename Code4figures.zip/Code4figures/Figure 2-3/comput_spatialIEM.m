 function [rSl]=comput_spatialIEM(cfg)
v2struct(cfg);
for x = 1:8
    eval([ 'location_' num2str(x) '_data =[];']);
end

% rng(seed)

eopch_index = dsearchn(dim.times',eopch');
% 
% dis_labels = {dim.chans.labels};
% elelabels_all = {dim.chans.labels};


 dis_labels = dim.chans;
 elelabels_all = dim.chans;

if strcmpi(ele_condition,'region')
%     for i = 1:length(ele)
%         ele_name = ele{i};
%         ele_index(i) = find(strcmpi(dis_labels,ele_name));
%     end
elseif strcmpi(ele_condition,'all')
    ele_index = [1:length(dis_labels)];
elseif strcmpi(ele_condition,'exclude')
    ele_index = [1:length(dis_labels)];
    for x = 1:length(ele)
        ele_name = ele{x};
        real_ele_index(x) = find(strcmpi(dis_labels,ele_name));
    end
    ele_index(real_ele_index)=[];
elseif strcmpi(ele_condition,'atlas')
    %ele_index =  [1:length(ele)];
    elelabels_all = ele;
    ele_index =  [1:length(ele)];
end

if strcmpi(power_condition,'phase')
     for x = 1:8
         fre_index = dsearchn(dim.freqs',frequency');
        eval([ 'data=angle(fre_power{' num2str(x) '});']);
        %data = data(:,fre_index(1):fre_index(end),:,:);
%         pase_cos = cos(data);
%         pase_sin = sin(data);
%         pase_data = squeeze(mean(pase_cos+pase_sin,2));
        eval([ 'location_' num2str(x) '_data_fre =data;']);
    end

else
    for x = 1:8
        eval([ 'location_' num2str(x) '_data_fre =fre_power{' num2str(x) '};']);
        %eval([ 'fre_power_ele{i} =location_' num2str(i) '_data_fre(ele_index,:,:) ;']);
    end
end
% data_path = ['I:\SL����\HBF\subject Z trial\Z eopch\-500 4000\60-100 Hz\only mixed design' filesep subject_name '_only_mixed_design_ele'];
%save(data_path,'fre_power_ele','dim','subject_name')

if strcmpi(load_trial_index,'yes')
    %trial_index_path = ['P:\SL����\behave\dis and mixed tar trial index\mixed dis\non prob' filesep subject_name '_dis_trial'];
    load(trial_index_path)
    for location = 1:8
        clear data_location data_trial
         eval(['data_trial =dis_location_all{' num2str(location) '}  ;'])
         eval(['data_location =dis_location_index_location_all{' num2str(location) '};'])
         for x = 1:length(data_location)

             trial_index = data_trial(x);
             trial_location = data_location(x);
            
             eval([ 'location_' num2str(location) '_data_RT(:,:,' num2str(x) ')= location_' num2str(trial_location) '_data_fre(ele_index,eopch_index,' num2str(trial_index) ');'])
          
         end
    end
     for x = 1:8
    
        eval([ 'location_' num2str(x) '_data =location_' num2str(x) '_data_RT;']);
     end
else
    for x = 1:8
        clear trial_index
        eval([ 'location_' num2str(x) '_data_RT =location_' num2str(x) '_data_fre(ele_index,eopch_index,:);']); 
    end
      for x = 1:8
        eval([ 'location_' num2str(x) '_data =location_' num2str(x) '_data_RT;']);
     end
end
% 
% if isfield(cfg,'baseline')
%     eopch_time = dim.times(eopch_index);
%     baseline_index = dsearchn(eopch_time',baseline');
%      for x = 1:8
%         eval(['baseline_data = mean(location_' num2str(x) '_data(:,baseline_index(1):baseline_index(end),:),2); '])
%         eval([ 'location_' num2str(x) '_data =location_' num2str(x) '_data - repmat(baseline_data,[1,length(eopch_time),1]);']);
%      end
% end

% location_data=[];
% for location = 1:8
% 
%     eval(['location_data(:,:,:,location) = location_' num2str(location) '_data;']);
% end

train_data_all=[];
nbins = length(attention_location);
for x = 1:nbins
    location = attention_location(x);
    eval(['train_data_all = cat(3,train_data_all,location_' num2str(location) '_data);'])
end




%% ȫ������ѵ��
%elelabels_all = all_labels;
elelabels_all = elelabels_all(ele_index);
train_chanlabels =elelabels_all;
test_chanlabels = elelabels_all;

for x = 1:nbins
    location= attention_location(x);
    eval([ 'location_' num2str(location) '_marker = zeros(1,size(location_' num2str(location) '_data,3)) + ' num2str(x) ';']);
end


for x = 1:nbins
    location= attention_location(x);
    eval([ 'each_location_trial(' num2str(location) ') = size(location_' num2str(location) '_data,3);']);
end

trian_events=[];
nbins = length(attention_location);
for x = 1:nbins
    location = attention_location(x);
    eval(['trian_events = cat(2,trian_events,location_' num2str(location) '_marker);'])
end


test_events = trian_events;

if strcmpi(prob_condition,'prob')
    if strcmpi(condition,'mixed dis')
        [~,high_location] = max(each_location_trial);
        low_location = [1:8];
        low_location(high_location)=[];
       
        long_distance_location = high_location+4;
        if long_distance_location>8
            long_distance_location = high_location-4;
        end
        data_path = ['J:\SL����\each subject high location index\mixed dis' filesep subject_name '_high_location'];
        save(data_path,'high_location','low_location')
        
    elseif strcmpi(condition,'only tar')
         [~,high_location] = max(each_location_trial);
        low_location = [1:8];
        low_location(high_location)=[];
       
        long_distance_location = high_location+4;
        if long_distance_location>8
            long_distance_location = high_location-4;
        end
        data_path = ['J:\SL����\each subject high location index\only tar' filesep subject_name '_high_location'];
        save(data_path,'high_location','low_location')
    else
        data_path = ['J:\SL����\each subject high location index\mixed dis' filesep subject_name '_high_location'];
        load(data_path)
    end


       data_path = ['J:\SL����\each subject high location index\mixed dis' filesep subject_name '_high_location'];
        load(data_path)

     low_location = [1:8];
  

     low_location(high_location)=[];
     

end

% 
% 
%     long_distance_location = high_location+4;
%     if long_distance_location>8
%         long_distance_location = high_location-4;
%     end


% parameters to set
em.mean_trial = mean_trial;
em.each_location_trial = each_location_trial;
em.winsize = winsize;
em.nChans = nbins; % # of channels
em.nBins = em.nChans; % # of stimulus bins
em.nIter = nIter; % # of iterations �������ٴ�
em.nBlocks = nBlocks; % # of blocks for cross-validation ������ʵ����ȷ�Ϊ3��block����Ĵ������ӵ��������Ҫ��ε�����������Ϊ�����̶ȵ�����trials
em.freqs = 1;
em.bands = {'all fre'};
em.time = dim.times(eopch_index);
em.test_time = dim.times(eopch_index);
em.Fs =500; % sampling rate of pre-processed data ������downsample֮ǰ�Ĳ���Ƶ���Ƕ���
em.window = 1000/500; % 1 data point per 4 ms  ԭ���Ĳ������Ƕ��٣���һ��ʱ���Ӧ���Ƕ���ms,����down��250hz�����һ��ʱ������1000/250=4ms
em.nElectrodes = length(elelabels_all);;%ʵ�����˶��ٸ��缫 �������Ƚ���ȫ���缫�ķ���������Щ�缫�ǻ��缫������ڷ�����ʱ��ҪС��һЩ�����缫�Ͳ�Ҫ������
em.posBin_train = trian_events;
em.posBin_test = test_events;


% for brevity in analysis
% ��һ����ʵ�����ĵģ����ǽ�֮ǰ���úõĲ������룬��Ϊ�����������Ҫ�ϴ������Կ�����Ҫ���������ˣ���������Լ��Ĵ��룬�ҿ��ܾͲ���д��һ��
nChans = em.nChans;
nBins = em.nBins;
nIter = em.nIter;
nBlocks = em.nBlocks;
freqs = 1;
times = em.time;
nFreqs = 1;
nElectrodes = em.nElectrodes;
evoked_nsample =  length(em.time);
nSamps = length(em.time);
if strcmpi(downsample_condition,'yes')
    nSamps = length(downsample);
    point = em.Fs./down_hz;
end
Fs = em.Fs;



% Specify basis set
%��һ����Ϊ�˵õ�C��Ҳ�������Ǽ�����ע������ͨ���ķֲ�
em.sinPower = sinPower; %%7
em.x = linspace(0, 2*pi-2*pi/nBins, nBins);%8��chanle
em.cCenters = linspace(0, 2*pi-2*pi/nChans, nChans);%bin��chanle����ûʲô����
em.cCenters = rad2deg(em.cCenters);%�û����ƽ�����ת��Ϊ�Ƕ�
pred = sin(0.5*em.x).^em.sinPower; % hypothetical channel responses%������Ǽ���ÿ��ͨ����power
pred = wshift('1D',pred,nBins/2+1); % shift the initial basis function %wshift����������ƶ�����������������з�ʽ�����ƶ�����ǰ�ƶ�
basisSet = nan(nChans,nBins);
for c = 1:nChans
    basisSet(c,:) = wshift('1D',pred,-c); % generate circularly shifted basis functions ÿ��һ��ͨ�����ƶ�һ�Σ����������Լ�����ͼ�������ˣ������8�����ȽϺô������������ά�ռ䣬���ܾ���Ҫһ������ѧ������
end
em.basisSet = basisSet; % save basis set to data structure
%% ѵ�����ݼ�
% trial
em.nTrials = length(trian_events); 
em.test_nTrials = length(test_events); 
nTrials = em.nTrials; % # of good trials
test_trials = em.test_nTrials;




nTimes = length(times);
% Preallocate Matrices
tf_evoked = nan(nFreqs,nIter,nSamps,nBlocks,nChans);  tf_total = tf_evoked;

C2_evoked = nan(nFreqs,nIter,nSamps,nBlocks,nBins,nChans); C2_total = C2_evoked;
W_evoked = nan(nFreqs,nIter,nSamps,nBlocks,nBins,nElectrodes);


tf_high = tf_evoked;
tf_low  = tf_evoked;
tf_long_distance = tf_evoked;

shift_C2 = C2_evoked;
%em.blocks = cell(1,10);  % create em.block to save block assignments
em.blocks = nan(nTrials,nIter);
em.test_blocks = nan(test_trials,nIter);




for iter = 1:nIter
    % ���ݲ��Ի�ѵ�������ٵ�trial����ɸѡ
    trian_posBin = trian_events;
    test_posBin  = test_events;
    % trian and test posBin
    train_blocks = nan(size(trian_posBin));
    test_blocks  = nan(size(test_posBin));

    shuffBlocks = nan(size(trian_posBin));
    test_shuffBlocks = nan(size(test_posBin));
    % count number of trials within each position bin
    clear binCnt test_binCnt
    for bin = 1:nBins
        pos_marker = bin; %% ������Ҫ�޸� train
        test_marker = bin; %% ����Ҳ��Ҫ�޸� test
        test_binCnt(bin) = sum(test_posBin == test_marker);%% ����Ҳ��Ҫ�޸�
        binCnt(bin) = sum(trian_posBin == pos_marker);
    end

    test_Cnt = min(test_binCnt);
    train_Cnt = min(binCnt);



    train_nPerBin = floor(train_Cnt/nBlocks); % max # of trials such that the # of trials for each bin can be equated within each block
    test_nPerBin  = floor(test_Cnt/nBlocks);
    % shuffle trials
    % ��trial�������
    shuffInd = randperm(nTrials)'; % create shuffle index
    shuffBin = trian_posBin(shuffInd); % shuffle trial order

    test_shuffInd =  randperm(test_trials)';
    test_shuffBin = test_posBin(test_shuffInd);
    % take the 1st nPerBin x nBlocks trials for each position bin.
    % trian ����Ҫ�����Ҹ��˾��ÿ��Բ��䣬��Ϊtrain��test�٣�����ֻҪtest����൱��trainҲ�ڱ�
    for bin = 1:nBins
        pos_marker = bin;%% ����Ҳ��Ҫ�޸�
        test_marker = bin;%% ����Ҳ��Ҫ�޸�

        test_idx = find(test_shuffBin == test_marker);
        text_idx = test_idx(1:test_nPerBin*nBlocks); % drop excess trials

        idx = find(shuffBin == pos_marker); % get index for trials belonging to the current bin
        idx = idx(1:train_nPerBin*nBlocks); % drop excess trials

        train_x = repmat(1:nBlocks',train_nPerBin,1);
        test_x  = repmat(1:nBlocks',test_nPerBin,1);

        shuffBlocks(idx) = train_x; % assign randomly order trials to blocks
        test_shuffBlocks(text_idx) = test_x;
    end

    % unshuffle block assignment
    train_blocks(shuffInd) = shuffBlocks;
    test_blocks(test_shuffInd) = test_shuffBlocks;
    % save block assignment
    em.blocks(:,iter) = train_blocks; % block assignment
    em.test_blocks(:,iter) = test_blocks; % block assignment
    em.nTrialsPerBlock = length(train_blocks(train_blocks == 1)); % # of trials per block
    em.test_nTrialsPerBlock = length(test_blocks(test_blocks == 1)); % # of trials per block
    em.each_block_bins_trial = train_nPerBin;
end





for f = 1:nFreqs
    tic

%     train_data_all = train_data_all(ele_index,:,:);
    for iter = 1:nIter
        if strcmpi(report_condition,'yes')
            fprintf('��:\t%d ��\n',iter)
        end
        train_blocks = em.blocks(:,iter);
        test_blocks = em.test_blocks(:,iter);
        if size(train_blocks,1)>size(train_blocks,2)
            train_blocks = train_blocks';
           
        end

        % Average data for each position bin across blocks
        posBins = 1:nBins;
        pos_markers = 1:nBins;%% ����Ҳ��Ҫ�޸�
        test_markers = 1:nBins;%% ����Ҳ��Ҫ�޸�
        if strcmpi(mean_trial,'yes')
            blockDat_evoked = nan(nBins*nBlocks,nElectrodes,evoked_nsample); % averaged evoked data
            blockDat_total = nan(nBins*nBlocks,nElectrodes,evoked_nsample);  % averaged total data
            test_blockDat_evoked = nan(nBins*nBlocks,nElectrodes,evoked_nsample); % averaged evoked data
            test_blockDat_total = nan(nBins*nBlocks,nElectrodes,evoked_nsample);  % averaged total data
        else
            blockDat_evoked = nan(nBins*nBlocks,nElectrodes,evoked_nsample,train_nPerBin); % averaged evoked data
            blockDat_total = nan(nBins*nBlocks,nElectrodes,evoked_nsample,train_nPerBin);  % averaged total data
            test_blockDat_evoked = nan(nBins*nBlocks,nElectrodes,evoked_nsample,train_nPerBin); % averaged evoked data
            test_blockDat_total = nan(nBins*nBlocks,nElectrodes,evoked_nsample,train_nPerBin);  % averaged total data
        end
        labels = nan(nBins*nBlocks,1);                           % bin labels for averaged data
        blockNum = nan(nBins*nBlocks,1);                         % block numbers for averaged data
        c = nan(nBins*nBlocks,nChans);                           % predicted channel responses for averaged data
        bCnt = 1;

        if strcmpi(mean_trial,'yes')
            for ii = 1:nBins 
                for iii = 1:nBlocks
                blockDat_evoked(bCnt,:,:) = squeeze(mean(train_data_all(:,:,trian_posBin==pos_markers(ii)& train_blocks==iii),3));%
           
                %blockDat_evoked(bCnt,:,:) = abs(squeeze(mean(fdata_evoked(trial_condition(1,trial_condition_index),:,:),1))).^2;%Ϊʲô����Ҫƽ�����о�û��Ҫ
                %blockDat_total(bCnt,:,:) = squeeze(mean(fdata_total(trial_condition(1,trial_condition_index),:,:),1));%���total������
                labels(bCnt) = ii;
                test_labels(bCnt) = ii; % ���˾����ⲽ���Բ�д����

                blockNum(bCnt) = iii;
                c(bCnt,:) = basisSet(ii,:);
                bCnt = bCnt+1;
                end
            end
        else
             for ii = 1:nBins 
                for iii = 1:nBlocks
                blockDat_evoked(bCnt,:,:,:) = train_data_all(:,:,trian_posBin==pos_markers(ii)& train_blocks==iii);%
                %blockDat_total(bCnt,:) = squeeze(mean(fdata_total(trian_posBin==pos_markers(ii)& train_blocks'==iii,:,tois),1));%���total������
                %blockDat_evoked(bCnt,:,:) = abs(squeeze(mean(fdata_evoked(trial_condition(1,trial_condition_index),:,:),1))).^2;%Ϊʲô����Ҫƽ�����о�û��Ҫ
                %blockDat_total(bCnt,:,:) = squeeze(mean(fdata_total(trial_condition(1,trial_condition_index),:,:),1));%���total������
                labels(bCnt) = ii;
                test_labels(bCnt) = ii; % ���˾����ⲽ���Բ�д����

                blockNum(bCnt) = iii;
                c(bCnt,:) = basisSet(ii,:);
                bCnt = bCnt+1;
                end
            end
        end
        

        for t = 1:nSamps % ������Ϊ�˿�˲ʱ��power %% ����Ҳ��Ҫ�޸� win_size 426
            % grab data for timepoint 
            if winsize>0
                
                toi = find(ismember(times,times(t)-winsize/2:times(t)+winsize/2)); % time window of interest ��Ȥ��
                 de = squeeze(mean(blockDat_evoked(:,:,toi),3)); % evoked data��ÿ��ʱ���
                
            else
                if strcmpi(mean_trial,'yes')
                     de = squeeze(blockDat_evoked(:,:,t)); % evoked data��ÿ��ʱ���
                  
                else
                     de = squeeze(blockDat_evoked(:,:,t,:)); % evoked data��ÿ��ʱ���
                end
                
            end
% 
   
           
           
%             % Do forward model

            for x=1:nBlocks % loop through blocks, holding each out as the test set
                trnl = labels(blockNum~=x); % training labels
                tstl = labels(blockNum==x); % test labels
                %-----------------------------------------------------%
                % Analysis on Evoked Power                            %
                %-----------------------------------------------------%
                B1 = de(blockNum~=x,:);    % training data
                B2 = de(blockNum==x,:);    % test data
                C1 = c(blockNum~=x,:);     % predicted channel outputs for training data
                W = C1\B1;          % estimate weight matrix
                C2 = (W'\B2')';     % estimate channel responses




                C2_evoked(f,iter,t,x,:,:) = C2; % save the unshifted channel responses���ڶ���ά���ǵ���������Ҳ���ظ����ٴ�
                                                % fs iter time block location  channle


                % shift eegs to common center
                n2shift = ceil(size(C2,2)/2);

                for ii=1:size(C2,1)
                    [~, shiftInd] = min(abs(posBins-tstl(ii)));
                    C2(ii,:) = wshift('1D', C2(ii,:), shiftInd-n2shift-1);
                end

                shift_C2(f,iter,t,x,:,:) = C2;
                tf_evoked(f,iter,t,x,:) = mean(C2,1); % average shifted channel responses
                                                      % �����������û���ã�����û��ɾ������Ϊ�������Ӱ�����ݴ�С�Ĺؼ�

                if strcmpi(prob_condition,'prob')
                        tf_high(f,iter,t,x,:) = C2(high_location,:); % average shifted channel responses
                        tf_low(f,iter,t,x,:) = mean(C2(low_location,:),1); % average shifted channel responses
                        tf_long_distance(f,iter,t,x,:) = C2(long_distance_location,:); % average shifted channel responses
              
      
                    
                     
                end
        

             end
        end
    end
    toc
end
em.ele_name = ele;
em.tar.shift_C2 = shift_C2;
em.tar.evoked = C2_evoked;
em.tar.mean_evoked = tf_evoked;
em.nBlocks = nBlocks;
em.each_location_trial = binCnt;
em.seed = cfg.seed;
if strcmpi(prob_condition,'prob')
        em.tar.evoked_high= tf_high;
        em.tar.evoked_low= tf_low;
    em.tar.evoked_long_distance= tf_long_distance;
end
rSl.seed = cfg.seed;


%% ��������ǰҪȷ������·���Ƿ���ȷ
fName_folder = [fName_folder filesep condition];
if ~exist(fName_folder)
    mkdir(fName_folder)
end
subject_name = [subject_name '_iem_Z_' condition '_' ele_condition '_' prob_condition];
fName = [fName_folder filesep subject_name '.mat'];
if strcmpi(save_train_data,'yes')
 %save(fName,'em','subject_name','train_data_all','-v7.3');
 save(fName,'em','subject_name','-v7.3');
end
% save(fName,'em','subject_name','-v7.3');
%%% CTF
CTF_folder = [fName_folder filesep 'no permu'];
if ~exist(CTF_folder)
    mkdir(CTF_folder)
end
CTF_fname = [CTF_folder filesep subject_name '.mat'];
if ~strcmpi(prob_condition,'prob')
    rDat.evoked = squeeze(mean(mean(em.tar.mean_evoked,2),4));
   % nSamps = length(em.time);
    for samp = 1:nSamps
        dat = squeeze(rDat.evoked(samp,:));
        x = 1:5;
        d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
        fit = polyfit(x,d,1);
        rSl.evoked(samp)= fit(1) ;
    end
  
     rSl.time = em.time;
    
else
    rDat.all_location = squeeze(mean(mean(em.tar.shift_C2,2),4));
    rDat.evoked_high = squeeze(mean(mean(em.tar.evoked_high,2),4));
    rDat.evoked_low = squeeze(mean(mean(em.tar.evoked_low,2),4));
     rDat.evoked_long_distance = squeeze(mean(mean(em.tar.evoked_long_distance,2),4));
    rDat.evoked = squeeze(mean(mean(em.tar.mean_evoked,2),4));
    %nSamps = length(em.time);
    for samp = 1:nSamps
        dat = squeeze(rDat.evoked(samp,:));
        x = 1:5;
        d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
        fit = polyfit(x,d,1);
        rSl.evoked(samp)= fit(1) ;
    end
    
    
    for samp = 1:nSamps
        %% high
        dat = squeeze(rDat.evoked_high(samp,:));
        x = 1:5;
        d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
        fit = polyfit(x,d,1);
        rSl.evoked_high(samp)= fit(1) ;
        
        %% low
        dat = squeeze(rDat.evoked_low(samp,:));
        x = 1:5;
        d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
        fit = polyfit(x,d,1);
        rSl.evoked_low(samp)= fit(1) ;
         %% long_distance
        dat = squeeze(rDat.evoked_long_distance(samp,:));
        x = 1:5;
        d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
        fit = polyfit(x,d,1);
        rSl.evoked_long_distance(samp)= fit(1) ;
    end

     for samp = 1:nSamps
         for location = 1:8
             if location == 1
                %% high
                dat = squeeze(rDat.all_location(samp,high_location,:));
                x = 1:5;
                d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
                fit = polyfit(x,d,1);
                rSl.all_location(location,samp)= fit(1) ;
             else
                 location_number = high_location+location-1;
                 if location_number>8
                     location_number = abs(location_number-8);
                 end
                dat = squeeze(rDat.all_location(samp,location_number,:));
                x = 1:5;
                d = [dat(1),mean([dat(2),dat(8)]),mean([dat(3),dat(7)]),mean([dat(4),dat(6)]),dat(5)];
                fit = polyfit(x,d,1);
                rSl.all_location(location,samp)= fit(1) ;
             end
        
    
         end
    end
    
    rSl.diff_ctf = rSl.evoked_high - rSl.evoked_low;
    if strcmpi(downsample_condition,'yes')
        rSl.time = downsample;
    else
         rSl.time = em.time;
    end
    
end


if strcmpi(save_CTF,'yes')
    save(CTF_fname,'rSl','subject_name')
end
end