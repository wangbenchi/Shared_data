%% chaning decoding
% train:WM
% test: high-1
% rong qi lin
% 12.25.2020
% 3.1.2021 change to distractor
clc,clear
%cd('\\desktop-nsg699e\j\SL����\HBF\subject Z trial\Z eopch\-500 4000\60-100 Hz\all tar dis')
%cd('\\desktop-nsg699e\h\bipolar refernece')
%cd('\\desktop-nsg699e\d\SL result\SL trial power\search onset\prob\theta')
addpath(genpath('\\Desktop-nsg699e\j\code\SL\IEM\TF Z'))
addpath(genpath('\\Desktop-nsg699e\j\code\SL'))
addpath('\\Desktop-nsg699e\j\code\SL\IEM\TF Z');

[filename,filepath]=uigetfile('*.mat');
fname = dir(fullfile(filepath,'*.mat'));
% number= randi([1,1000000]);
% %seed =rng('default');
% seed =rng(number);
all_number = length(fname);
prob_condition = 'non prob';
condition = 'mixed dis';
%RT_condition = 'slow';
downsample_condition = 'no';
%region ={'STG','MTG','Amygdala','ACC','PFC','IP'};
%region ={'precuneus','IP','Hippocampus','PFC'};
%region = {'SP','sp'}; %% Postcentral
%exclude = {'bone','unknown','none'};
%region = {'supramarginal'};
ele_condition = 'region';%% all, region, atlas each ele
%response_network = {'Dorsal attention','Ventral attention','Visual','Frontoparietal'};
response_network = {'Default','Limbic'};
%positive_region = {'PFC','IP','precunes','hippocampus'};
%resnpose_atlas =  {'middletemporal'};
%resnpose_atlas = positive_region;
%condition_list = nchoosek(resnpose_atlas,5);%% RSM_permutation
%exclude_atlas = {'Ventral Attention';'Frontoparietal';'Visual';'Limbic';'Default';'FreeSurfer_Defined_Medial_Wall';'Somatomotor'};
% exclude_atlas = {'none','bone'};
%train_time = [-1200 -10002
%region = 'MTG'
fast_slow_trial_folder = ['\\Desktop-nsg699e\j\SL����\behave\fast and slow RT trial\all location\50%\' condition];
EEG_RT_folder = '\\Desktop-nsg699e\j\SL����\EEG_RT\all trial dis';
behave_folder = ['\\Desktop-nsg699e\j\SL����\behave\dis and mixed tar trial index'];
fName_folder = ['K:\IEM(SL)\bipolar reference �޳��ķ�λ��\����\train non prob test prob\25 winsize 6 block 50 iter 7 power' filesep prob_condition];
%ele_folder = 'J:\SL����\HBF ele\����\Z score\60-100 Hz bipolar\FDR control';
ele_folder = 'J:\SL����\HBF ele\����\Z score prob and non prob\bipolar reference �޳��ķ�λ��\FDR time control';
 other_frequency = ['K:\TF power\search onset (-500 6000)\bipolar reference �޳��ĸ���׼��\prob' ];
for z = 1
    if strcmpi(condition,'only tar')
        load_trial_index = 'no';
%         network_atlas_path = ['H:\SL����\HBF ele\����\Z score\60-100 Hz FDR\DK atlas' filesep 'all_dis_none_DK_atlas'];
%         load(network_atlas_path)
    elseif strcmpi(condition,'all trial dis')
        load_trial_index = 'no';
%         network_atlas_path = ['H:\SL����\HBF ele\����\Z score\60-100 Hz FDR\DK atlas' filesep 'all_dis_none_DK_atlas'];
%         load(network_atlas_path)
    else
        load_trial_index = 'yes';
%         network_atlas_path = ['H:\SL����\HBF ele\����\Z score\60-100 Hz FDR\DK atlas' filesep 'all_dis_none_DK_atlas'];
%         load(network_atlas_path)
    end
end
%atlas_subject_info = all_ele_atlas(:,4);
% [NUM,TXT,RAW]=xlsread('\\Desktop-nsg699e\i\�ں�ͼ\�缫��Ϣ\subject ele atlas');
% RAW(1,:)=[];
% subject_infor = RAW(:,8);
% subject_infor = strrep(subject_infor,'''','');
% 
% atlas_infor = RAW(:,6);
% atlas_infor = strrep(atlas_infor,'''','');
% 
% network_infor = RAW(:,9);
% % network_infor = strrep(network_infor,'''','');

[NUM,TXT,RAW]=xlsread('\\Desktop-nsg699e\j\SL����\HBF ele\DK atlas.xlsx',2);
RAW(1,:)=[];
atlas_subject_info = RAW(:,10);
atlas_subject_info = strrep(atlas_subject_info,'''','');

subject_infor = RAW(:,5);
subject_infor = strrep(subject_infor,'''','');

atlas_subject_ele = RAW(:,10);


all_ele_atlas = RAW(:,2);

ele_labels_folder = 'J:\SL����\bioplar clean\bipolar reference �޳��ķ�λ��\fixation\non prob'

 for id =1:18
     

    clear fre_phase
        clear real_ele_all fre_power name ele_name_all trial_index_path
        clear    fre_power_alpha fre_power_beta
    
        subject_file = fname(id).name;
    
        data_path = [filepath subject_file];
     
    
        if strcmpi(condition,'only tar')
            name = subject_file(1:end-51);
            ele_path = [ ele_folder '\only tar' filesep name '_positive_only tar_ele_Z'];
            %ele_path = [ ele_folder  filesep name '_positive_mixed dis non_ele_Z'];
        else
            name = subject_file(1:end-54);
            ele_path = [ ele_folder '\mixed dis none' filesep name '_positive_mixed dis non_ele_Z'];
          %ele_path = [ ele_folder  filesep name '_positive_mixed dis non_ele_Z'];
        end
        ele_labels_path = [ele_labels_folder filesep name '_dis_none'];
    load(ele_labels_path,'ele_refernce_labels_clean')
    

    
%       EEG_RT_path = [EEG_RT_folder filesep name];
% 
%       load(EEG_RT_path)
%     
        load(data_path)
            
    
        load(ele_path)


% 
%         subject_index = find(strcmpi(subject_infor,subject_name));
% 
%             
%             %subject_ele = ele_infor(subject_index);
% 
%             
%             
%             subejct_network = RAW(subject_index,10);        
%             subejct_network = strrep(subejct_network,'''','');
% % 
%              subejct_atlas_ele = RAW(subject_index,2);  
%             subject_atals_info = RAW(subject_index,9);     
%             subject_atals_info = strrep(subject_atals_info,'''','');
% % 
%             
%             subejct_atlas_hel = RAW(subject_index,4);   
%             subejct_atlas_hel = strrep(subejct_atlas_hel,'''','');
% % 
% % % %             real_ele_all = ele_labels(ele_index);
%             network_index = find(ismember(subejct_network,response_network));
% %             
%             network_ele = subejct_atlas_ele(network_index);
%             network_atlas = subject_atals_info(network_index);
%             netwrok_hel = subejct_atlas_hel(network_index);
%             network_name = subejct_network(network_index);
%             
% %             atlas_index = find(ismember(subject_atals_info,region_atlas));
% %             atlas_ele = subejct_atlas_ele(atlas_index);
% %             atlas_hel = subejct_atlas_hel(atlas_index);
% %             atlas_name = subject_atals_info(atlas_index);
% 
% % 
% 
%           
% %       
%             %% �޳�IED �缫
%             response_hel = strrep(netwrok_hel,'''','');
%             atlas_real_name = {};
%             for i =1:length(network_ele)
%                 ele_hel = response_hel{i};
%                 ele_name = network_ele{i};
%                 ele_name(end)=[];
%                 if strcmpi(ele_hel,'R')
%                     ele_name = strrep(ele_name,'''''','''');
%                 end
%                 atlas_real_name{i} = ele_name;
%             end
% 
%             positive_ele = intersect(real_ele_all,atlas_real_name);




% 

%     if strcmpi(ele_condition,'region')
%         ele_labels =ele_refernce_labels_clean;
%          %ele_labels = {dim.chans.labels}   ;
%         real_ele_index = [];
%         for i =1:length(real_ele_all)
%             ele_name = real_ele_all{i};
%             real_ele_index(i) = find(strcmpi(ele_labels,ele_name));
%         end
% 
%     else
%           ele_labels ={dim.chans.labels} ;
%          real_ele_all = ele_labels;
%         real_ele_index = [1:length(ele_labels)];
%     
%     end
%     all_ele = [1:length(ele_labels)];
%     diff_ele = setdiff(all_ele,real_ele_index);
%     real_ele_index = diff_ele;
        %real_ele_index = shuffle(real_ele_index);
    
    % %     
    %     real_ele_all = ele_labels(positive_sig_index);
    %     real_ele_index = positive_sig_index;
    
        
        
        
        
    
            if strcmpi(condition,'mixed tar dis')
                trial_index_path = [ behave_folder '\mixed tar dis\' prob_condition filesep name '_mixed_tar_dis_trial'];
            elseif strcmpi(condition,'mixed tar')
                trial_index_path = [ behave_folder '\mixed tar\' prob_condition filesep name '_mixed_tar_trial'];
            elseif strcmpi(condition,'mixed dis')
                trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep name '_dis_trial'];  
            else
                trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep name '_dis_trial'];  
            end
            %% cross data
    
        clear train_data_power
        ele_labels = ele_refernce_labels_clean;
        real_ele_index_train = [];
        for i =1:length(real_ele_all)
            ele_name = real_ele_all{i};
            real_ele_index_train(i) = find(strcmpi(ele_labels,ele_name));
        end
            
        for n = 1:8
            data = fre_power{n};
            train_data_power{n} = data(real_ele_index_train,:,:);
        end
            cfg.train_power = train_data_power;
            %dim.times = [-1000:2:1500];
             %dim.ele_labels = ele_refernce_labels;
            cfg.train_dim = dim;
            %cfg.train_epoch = [200 400];
    % %         
    % % % % % %         
    % % % % % %         
    % % % % % %         
    % % % % % %         % test
    % % % % % % % % 

            clear test_data_power fre_power
            other_frequency_path = [other_frequency filesep name '_TF_output_all_tar_dis_none_conavg_HFB_60-100 HZ_Z'];
            load(other_frequency_path)
        ele_labels = ele_refernce_labels_clean;
        real_ele_index_test = [];
        for i =1:length(real_ele_all)
            ele_name = real_ele_all{i};
            real_ele_index_test(i) = find(strcmpi(ele_labels,ele_name));
        end
        for n = 1:8
            data = fre_power{n};
            test_data_power{n} = data(real_ele_index_test,:,:);
        end


            cfg.test_power = test_data_power;
            %dim.times = [-1250:2:1000]+1250;
            %dim.times = [-1000:2:1500];
            %dim.ele_labels = ele_labels;
            cfg.test_dim = dim;
    %         cfg.test_time = [-500:2:6000];
        niter = 500;


    if length(real_ele_index) >8
     for x = 1
%          if x ==1
%             RT_condition = 'fast';
%          else
%             RT_condition = 'slow';
%          end
        for iter = 1
%                 subject_folder = [fName_folder filesep name];
%                 if ~exist(subject_folder)
%                     mkdir(subject_folder)
%                 end
% 
%                 iter_foler = [fName_folder filesep num2str(iter)];
%                 if ~exist(iter_foler)
%                     mkdir(iter_foler)
%                 end
                number= randi([1,1000000]);
                seed =rng(number);
                
                cfg.seed = seed;
                cfg.load_trial_index =load_trial_index;
                cfg.fName_folder = fName_folder; %% data save folder
                cfg.attention_location = [1:8];
                cfg.frequency =  [8 12];
                cfg.ele_index = real_ele_index;
                %cfg.location_RT =location_RT;
                %cfg.trial_index = 'mixed dis';
                cfg.prob_condition = prob_condition;
                cfg.ele_condition = ele_condition; %% exclude,region, all ,atlas
                cfg.trial_index_path = trial_index_path;
                cfg.condition = condition;
                cfg.subject_name = name ;

                dim.chans = ele_refernce_labels_clean;

                %cfg.subject_name = num2str(iter) ;
                cfg.winsize =25; %% ms +-
                cfg.sinPower =7; %% 7 or 25
                 cfg.dim = dim;
                cfg.eopch = [0:2:1000];
                cfg.downsample_condition =downsample_condition;
                if strcmpi(downsample_condition,'yes')
                    cfg.raw_hz = 500;
                    cfg.down_hz = 125;
                    cfg.downsample = [-500:8:1500];
                end
                %cfg.train_epoch = [200 400];
                %cfg.each_trial = 50;
                cfg.nBlocks =6; %% prob 6block
                cfg.ele = real_ele_all;
%                 try
%                     cfg.fre_power = fre_power;
%                 catch
%                     cfg.fre_power = fre_power_alpha;
%                 end
                cfg.mean_trial = 'yes';
                cfg.data_condition = 'no';
                cfg.power_condition = 'power';
                cfg.save_train_data = 'no';%% if want to permutation
                cfg.nIter =50; %% gamma iter20 6 block 30 theta prob 50iter
                cfg.report_condition = 'no';
                cfg.save_CTF ='yes';
                %cfg.baseline = [-200 -0];
               % comput_spatialIEM_cross_time(cfg);
                %comput_spatialIEM_train_target_test_dis_vice(cfg);
                %comput_spatialIEM_cross_time_cross_data(cfg);
                %comput_spatialIEM_cross_time_compute_wm_accolation(cfg);
               comput_spatialIEM_cross_time_cross_data_test_non_prob(cfg);
                %comput_spatialIEM_one_location(cfg);
               %comput_spatialIEM(cfg);
               %comput_spatialIEM_iter_random_trial(cfg);
               %comput_spatialIEM_leave_one_out(cfg);
               %comput_spatialIEM_each_subject_iter(cfg);
               %comput_spatialIEM_SL_distribution(cfg);
               %comput_spatialIEM_test_non_prob_train_prob(cfg);
                
                %comput_spatialIEM_one_channel(cfg);
                %comput_noise_corr(cfg);%% �������
                
    
                
                %comput_spatialIEM_within_iter(cfg);
                %comput_spatialIEM_each_ele(cfg)
                %comput_spatialIEM_pca(cfg);
                %gamma_PCA(cfg);
                %comput_spatialIEM_both_target_and_dis(cfg);
    
                
                %% fast and slow
%                 fast_slow_index = [fast_slow_trial_folder filesep subject_name '_fast_slow_RT_trial'];
%                 load(fast_slow_index)
%                 cfg.RT_condition = RT_condition;
%                 cfg.all_RT_trial_fast_index = all_RT_trial_fast_index;
%                 cfg.all_RT_trial_fast_location = all_RT_trial_fast_location;
%                 cfg.all_RT_trial_slow_index = all_RT_trial_slow_index;
%                 cfg.all_RT_trial_slow_location = all_RT_trial_slow_location;
%     
%                 comput_spatialIEM_fast_slow(cfg)
         
                
        end
                
     end
    end
end
clc,clear

    