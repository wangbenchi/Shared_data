clc,clear
atlas_file = dir()
save_data_path = ['K:\IEM(SL)\CTF cluster test'];
test_statistic = 'sum';
permutation_folder  = 'J:\SL����\IEM\gamma\Z score\permutation test\cluster\60-100 Hz';
%permutation_folder  = 'J:\SL����\IEM\gamma\Z score\permutation test\cluster\alpha and beta\gamma ele';
time = [0:2:1000];
eopch_index = dsearchn(time',[-0 1000]');
corrected_condition = 'no';
therold = 0.05;
clustertherold = 0.05;
z=3
for z = 1
    atlas_name = atlas_file(z+2).name;
    condition = dir(fullfile(atlas_name));
     save_data_folder = [save_data_path filesep atlas_name];
     if ~exist(save_data_folder)
         mkdir(save_data_folder)
     end

    %for x = 1:length(condition)-2
    for x =1:length(condition)-2
        clear subject_name
        condition_name = condition(x+2).name;
    
        if strfind(condition_name,'all trial dis')
            permutation_path = [permutation_folder filesep  'all tar dis none region ele Z 60-100 Hz eopch -500 4000_permutation'];
            
            load(permutation_path)
        else
            permutation_path = [permutation_folder filesep  'mixed dis none region ele Z 60-100 Hz eopch -500 4000_permutation'];
            %permutation_path = [permutation_folder filesep  'mixed dis none 60-100 Hz ele beta eopch -500 4000_permutation'];
            %permutation_path =['H:\SL����\IEM\cross time\permutation test\ mixed dis prob_permutation_cluster_test']
            load(permutation_path)
        end
        
    filepath = [atlas_name filesep condition_name filesep 'no permu']
    fname=dir(fullfile(filepath,'*.mat'));
    tm = time(eopch_index(1):eopch_index(end));
    nSamps = length(tm);
    Nsub = length(fname);
    Nitr = 10;  % ��������
    Ntp = length(tm);
    correction = 'cluster'; % 'cluster'

    bIter = 10000; % # of bootstrap iterations
for y = 1
    %create empty matrix
    AverageAccuracy = zeros(Nsub,Ntp);

for sub = 1:Nsub
    filename = fname(sub).name;
    full_path = [filepath filesep filename];
    load(full_path)
    
    subject_ctf = rSl.evoked(eopch_index(1):eopch_index(end));
    %smoothedAvg = smooth(subject_ctf,5);
    smoothedAvg = nan(1,Ntp);
     for tAvg = 1:Ntp
         if tAvg ==1
           smoothedAvg(tAvg) = mean(subject_ctf((tAvg):(tAvg+2)));
         elseif tAvg ==2
           smoothedAvg(tAvg) = mean(subject_ctf((tAvg-1):(tAvg+2)));
         elseif tAvg == (Ntp-1)
           smoothedAvg(tAvg) = mean(subject_ctf((tAvg-2):(tAvg+1)));
         elseif tAvg == Ntp
           smoothedAvg(tAvg) = mean(subject_ctf((tAvg-2):(tAvg)));
         else
           smoothedAvg(tAvg) = mean(subject_ctf((tAvg-2):(tAvg+2)));  
         end

     end
     
    
    AverageAccuracy(sub,:) =rSl.evoked(eopch_index(1):eopch_index(end)); % average across iteration and block
    %AverageAccuracy(sub,:) =subject_ctf; % average across iteration and block
    

end %End of subject
% Boostsrap
   boot.IDX = nan(bIter,Nsub);
    boot.SLOPE = nan(bIter,Nsub,nSamps);
    boot.M = nan(bIter,nSamps);

    % loop through bootstrap replications
    for b = 1:bIter
        fprintf('Bootstrap replication %d out of %d\n', b, bIter)

        [bSLOPE idx] = datasample(AverageAccuracy,Nsub,1); % sample nSubs many observations from realSl for the subs dimensions (with replacement)
        boot.IDX(b,:) = idx;      % save bootstrap sample index
        boot.SLOPE(b,:,:) = bSLOPE;   % save bootstrapped CTFs
        boot.M(b,:) = mean(bSLOPE); % get the mean osbserved slope (across subs)

    end

    % calculate the bootstrapped SE
    boot.SE = std(boot.M);

    % calculate actual mean CTF
    ctfSlope.mn = mean(AverageAccuracy);

%     % save slopes matrix
    ctfSlope.slopes = AverageAccuracy;
if strcmpi(corrected_condition,'yes')
    
    AverageAccuracy_abs = AverageAccuracy.^2;
    CTF_std = std(AverageAccuracy_abs,1,2);
    CTF_mean = mean(AverageAccuracy_abs,2);
    CTF_therold = CTF_mean+CTF_std*5;
    index=[];
    for i = 1:Nsub
        index(i) = sum(find(AverageAccuracy_abs(i,:)>CTF_therold(i)));
    end
    [CTF_std_sort,CTF_std_sort_index] = sort(CTF_std);
    number = Nsub-floor(0.9*Nsub);
    AverageAccuracy(CTF_std_sort_index(end-number+1:end),:)=[];
    subAverage = squeeze(mean(AverageAccuracy,1)); 
    seAverage = squeeze(std(AverageAccuracy,1))/sqrt(Nsub-number); 
else
    %now compute average accuracy across participants
    subAverage = squeeze(mean(AverageAccuracy,1)); 

    seAverage = squeeze(std(AverageAccuracy,1))/sqrt(Nsub); 
end


%% do cluster mass analyses
%releventTime = tStart:ntPerm; % from the onset of motion 

 
Ps = nan(2,Ntp);
for i = 1:Ntp% make sure this time range is correct
    %tp = releventTime(i);
    tp = i;
    [H,P,CI,STATS] =  ttest(AverageAccuracy(:,tp), 0,'tail','right'); % Test Against Zero

    Ps(1,i) = STATS.tstat;
    Ps(2,i) = P;
end

if strcmpi(correction,'FDR')
    pvals = Ps(2,:);
    [p_fdr, p_masked] = fdr(pvals, 0.05);
    
elseif strcmpi(correction,'cluster')
    % find significant points
    candid = Ps(2,:) <=therold;
    candid_marked = zeros(1,length(candid));
    candid_marked(1,1) = candid(1,1);
    candid_marked(1,length(candid)) = candid(1,length(candid));
    %remove orphan time points
    for i = 2:Ntp-1
        if candid(1,i-1) == 0 && candid(1,i) ==1 && candid(1,i+1) ==0
        candid_marked(1,i) = 0; 
        else
        candid_marked(1,i) = candid(1,i);     
        end

    end

% combine whole time range with relevent time & significant information
clusters = zeros(Ntp,1);
clusterT = zeros(Ntp,1);
clusters(:,1) = candid_marked;
clusterT(:,1) = Ps(1,:);
clusterTsum = sum(Ps(1,logical(candid_marked)));

%%find how many clusters are there, and compute summed T of each cluster
%%�����cluster��ȡ����Tֵ�����Tֵ����cluster�Ƚ�С��������ԣ�������Z������������ܻ����
tmp = zeros(10,25);
cl = 1;
member = 1;
for i = 2:length(clusters)-1
        if clusters(i-1) ==0 && clusters(i) == 1 && clusters(i+1) == 1 
            cl = cl+1;
            member = member +1;
            tmp(cl,member) = i;    
        
        elseif clusters(i-1) ==1 && clusters(i) == 1 && clusters(i+1) == 0 
            member = member +1;  
            tmp(cl,member) = i;    
            member = 0;  
        elseif clusters(i-1) ==1 && clusters(i) == 1 && clusters(i+1) == 1             
            member = member +1;  
            tmp(cl,member) = i;    
        
        else
        
            
        end
end

HowManyClusters = cl;
a = tmp(1:cl,:);
eachCluster = a(:,logical(sum(a,1)~=0));

%now, compute summed T of each cluster 
dat_clusterSumT = zeros(HowManyClusters,1);
for c = 1:HowManyClusters
   dat_clusterSumT(c,1) = sum(clusterT(eachCluster(c,eachCluster(c,:) ~=0)));
end
    
end



%% find .05 point
% max T-Threshold
% load('simulationT256_ERP_Response.mat') % load different null distribution of t-mass.
if strcmpi(correction,'cluster')
    iteration = 1000;
    cutOff = iteration - iteration * clustertherold; %one tailed
    % sortedTvlaues = sort(EmpclusterTvalue,2);
    critT = simulationT(cutOff); % 2 tailed iteration * 0.025
    sigCluster = dat_clusterSumT > critT;
    draw = eachCluster(sigCluster,:);
    draw = sort(reshape(draw,1,size(draw,1)*size(draw,2)));
    draw = draw(draw>0);

    for si = 1 :size(dat_clusterSumT,1)

    [~,where] = min(abs(simulationT - dat_clusterSumT(si)));
    pv = 1 - where/iteration
    end
    data_cluster = [save_data_folder filesep 'cluster'];
    data_no_cluster = [save_data_folder filesep 'no cluster'];
    if ~exist(data_cluster)
        mkdir(data_cluster)
    end
    if ~exist(data_no_cluster)
        mkdir(data_no_cluster)
    end
    data_dir = [data_cluster filesep condition_name]
    save(data_dir,'subAverage','draw','seAverage','tm','boot','-v7.3');
    
%     sigcluster = eachCluster(:);
%     sigcluster(sigcluster==0) =[];
%     data_dir = [data_no_cluster filesep condition_name]
%     save(data_dir,'subAverage','sigcluster','seAverage','tm','boot','-v7.3');
elseif strcmpi(correction,'FDR')
    draw = p_masked;
    data_dir = ['I:\SL����\IEM\gamma\Z score\spaitalIEM\60-100 Hz\������\k-folder\permutation test\' subject_name]
    save(data_dir,'subAverage','draw','seAverage','tm');
end
end
    end
 
  
end