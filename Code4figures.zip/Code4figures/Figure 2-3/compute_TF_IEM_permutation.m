%lin_IEM
%2020.9.14
% determine random seed
% rng shuffle; % get new random seed
% em.randSeed = rng; % save random seed to em structure
% clc,clear
prob_condition = 'non prob';
condition = 'mixed dis'
%network_condition = 'Ventral attention'
data_folder = ['\\Desktop-nsg699e\g\临时存放数据\SpatialIEM(尝试）\60-100 Hz (0-1500 ms corrected)\2022.9.20 (新分区) fast and slow\all location\备份\50%\mixed dis\permutaion slow'];
save_data_folder = [data_folder filesep 'permutation' filesep prob_condition filesep condition];
if ~exist(save_data_folder)
    mkdir(save_data_folder)
end

   

    for z = 1
  
  
    em.winsize =0;
    winsize = em.winsize;
    em.subject_name = subject_name;
    em.nPerms = 1000;
    nPerms = em.nPerms;
    %get analysis settings from TF data file.
    nChans = em.nChans;
    nBins = em.nBins;
    nIter = em.nIter;
    nBlocks = em.nBlocks;
    %freqs = em.freqs;
    times = em.time;
    nFreqs = 1;
    nElectrodes = em.nElectrodes;
    nSamps = length(em.time);
    Fs = em.Fs;
    basisSet = em.basisSet;
    posBin = em.posBin_train;
    nTrialsPerBlock = em.nTrialsPerBlock;
    train_nPerBin = em.nTrialsPerBlock/nBins;
    mean_trial = 'yes';
    % Loop through each frequency
    %f=1;
    for f = 1:nFreqs
      
          

        for iter =1:nIter

            blocks = em.blocks(:,iter); % grab blocks assignment for current iteration

            % Loop through permutations
            for perm = 1:nPerms
                fprintf('iter: %d Permutation %d out of %d\n',iter,perm,nPerms);

                %-----------------------------------------------------------------------------
                % Permute trial assignment within each block
                
                
                %-----------------------------------------------------------------------------
                permedPosBin = nan(size(posBin)); % preallocate permuted position bins vector
                for b = 1:nBlocks % for each block..
                    pInd = randperm(nTrialsPerBlock); % create a permutation index
                    permedBins(pInd) = posBin(blocks == b); % grab block b data and permute according data according to the index
                    permedPosBin(blocks == b) = permedBins; % put permuted data into permedPosBin
                    permInd(f,iter,perm,b,:) = pInd; % save the permutation (permInd is saved at end of the script)
                end

                
                
                %-----------------------------------------------------------------------------

                % Average data for each position bin across blocks
                posBins = 1:nBins;
                pos_markers = 1:nBins;
                blockDat_evoked = nan(nBins*nBlocks,nElectrodes,nSamps); % averaged evoked data
                labels = nan(nBins*nBlocks,1);                           % bin labels for averaged data
                blockNum = nan(nBins*nBlocks,1);                         % block numbers for averaged data
                c = nan(nBins*nBlocks,nChans);                           % predicted channel responses for averaged data
                bCnt = 1;

                for ii = 1:nBins
                    for iii = 1:nBlocks
                       
                        blockDat_evoked(bCnt,:,:,:) =mean(train_data_all(:,:,permedPosBin==pos_markers(ii) & blocks==iii),3);
                        labels(bCnt) = ii;
                        blockNum(bCnt) = iii;
                        c(bCnt,:) = basisSet(ii,:);
                        bCnt = bCnt+1;
                    end
                end

                for  t = 1:nSamps % 这里是为了看瞬时的power
              
             
                     if winsize >0
                        toi = find(ismember(times,times(t)-em.window/2*2:times(t)+em.window/2*2)); % time window of interest 兴趣区
                         de = squeeze(mean(blockDat_evoked(:,:,toi),3)); % evoked data，每个时间段

                    else

                        de = squeeze(blockDat_evoked(:,:,t)); % evoked data，每个时间段
                     end

                    % Do forward model

                    tmpeCR = nan(nBlocks,nChans); 
                    tmpeCR_high = nan(nBlocks,nChans); 
                    tmpeCR_low= nan(nBlocks,nChans); 
               
                   

                    for i=1:nBlocks % loop through blocks, holding each out as the test set

                        trnl = labels(blockNum~=i); % training labels
                        tstl = labels(blockNum==i); % test labels

                        %-----------------------------------------------------%
                        % Analysis on Evoked Power                            %
                        %-----------------------------------------------------%
                        B1 = de(blockNum~=i,:);    % training data
                        B2 = de(blockNum==i,:);    % test data
                        C1 = c(blockNum~=i,:);     % predicted channel outputs for training data
                        W = C1\B1;          % estimate weight matrix
                        C2 = (W'\B2')';     % estimate channel responses


                
                        % shift eegs to common center
                        n2shift = ceil(size(C2,2)/2);
                        for ii=1:size(C2,1)
                            [~, shiftInd] = min(abs(posBins-tstl(ii)));
                            C2(ii,:) = wshift('1D', C2(ii,:), shiftInd-n2shift-1);
                        end
                  
                        tmpeCR(i,:) = mean(C2); % average shifted channel responses
                    
                    end
                    % save data to indexed matrix
                     %C2_evoked(f,iter,perm,t,:,:) = squeeze(mean(tmpeC2));
                    % C2_total(f,iter,perm,t,:,:) = mean(tmptC2);
                    
                    tf_evoked(f,iter,perm,t,:) = mean(tmpeCR);
                
                end
            
            
            end
        end

    end
    
    fName = [save_data_folder filesep subject_name '_iem_permutation.mat']
    em.permInd = permInd;
    em.prob_condition = prob_condition;
    %em.permC2.evoked = squeeze(mean(C2_evoked,2)); %%not saving these because they're huge!
    %em.permC2.total = C2_total;
    % em.permtfs.each_location = C2_evoked;
    em.permtfs.mean_location = tf_evoked;

    save(fName,'em','subject_name','-v7.3');
    run('\\Desktop-nsg699e\j\code\SL\IEM\TF Z\lin_IEM_CTF_fre_mean_Z.m')
    end
