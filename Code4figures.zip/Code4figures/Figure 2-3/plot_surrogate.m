clc,clear
subject_file = dir('*.mat')
real_CTF_diff = CTF_infor(:,1);



real_CTF_diff_mean = mean(CTF_infor(:,1));

pic_folder = 'C:\Users\admin\Desktop\pic';

fontsize = 40;
nbins =50;
%real_CTF_color = [249,115,37]/256;
real_CTF_color = [0,32,96]/256;

%% positive
colormap = [210,19,18;252,79,0;247,149,64;255,217,102]/256;
positive = [11,10,5,1];

%colormap = [176,0,103;241,38,20;222,78,133;192,151,225]/256;
%colormap = [1,168,197;166,172,236;232,54,134;165,108,193;1,168,197]/256;
%colormap = [249,115,37;190,141,246;197,142,115;105,159,245]/256;
%colormap = [155,1,169;128,64,197;134,101,228;213,166,237]/256;
%% negative
% colormap = [74,140,134;95,189,1;15,198,164;36,234,29]/256;
% positive = [7,18,3,14]
alpha = 0.3;
%alpha = 1;



number = 4
for number =4
    
    id = positive(number)
    name = subject_file(id).name
    load(name)
     number_list = [1:1000];
     number_list = shuffle(number_list);
     real_list = [1:1000];
     real_list = shuffle(real_list);
     
 
    CTF_diff = CTF_infor(:,1);
    CTF_mean = mean(CTF_diff);
    
%     [CTF_sort,~] = sort(CTF_diff);
%     therold_high = CTF_sort(975);
%     therold_low = CTF_sort(25);
    
    real_CTF_diff_bins = real_CTF_diff;
    %CTF_diff = CTF_diff;
    real_ctf_bins = linspace(min(real_CTF_diff_bins),max(real_CTF_diff_bins),nbins+1);
    atlas_ctf_bins =  linspace(min(CTF_diff),max(CTF_diff),nbins+1);

  

    figure('Position',[1,1,700,700])
     set(gca,'FontSize',fontsize)
    %% Brain region
    H = histogram(CTF_diff,atlas_ctf_bins,'Normalization','count');hold on
    H.LineWidth = 0.1;
    H.FaceAlpha = alpha;
    H.EdgeColor = [1,1,1];
     
    H.FaceColor = colormap(number,:);
   
    x=[];
    for i = 2:nbins
        x(i-1) = 0.5*(H.BinEdges(i)+H.BinEdges(i-1));
    end
    z =H.Values+eps;
    [fitobject_atlas,gof] = fit(x',z(1:end-1)','gauss1');

    %% real CTF hist
    H2 = histogram(real_CTF_diff_bins,real_ctf_bins,'Normalization','count');hold on
    H2.LineWidth = 0.1;
    H2.FaceAlpha = alpha;
    H2.EdgeColor = [1,1,1];
    H2.FaceColor = real_CTF_color;
 
     x=[];
    for i = 2:nbins
        x(i-1) = 0.5*(H2.BinEdges(i)+H2.BinEdges(i-1));
    end
    z =H2.Values+eps;
    [fitobject_real,gof] = fit(x',z(1:end-1)','gauss1');
    
    
    
    %% fit curve

   
    F1 = plot(fitobject_atlas);hold on
    F1.LineWidth = 4;
    F1.Color = colormap(number,:);
    F2 = plot(fitobject_real);hold on
   F2.LineWidth = 4;
   F2.Color = real_CTF_color;
   set(gca,'FontSize',fontsize)
    %L = legend(name(1:end-4),'Default + Limbic');
   % L = legend('Superior temporal gyrus (STG)')
  L = legend('IP');
    L.EdgeColor = [1,1,1];

    L.Color = [1,1,1];
    L.Visible = 'off';
    L.Position = [0.28    0.85    0.0847    0.0267];
    line_1 = line([real_CTF_diff_mean,real_CTF_diff_mean],[0 80],'LineStyle','--')
    line_1.LineWidth = 5;
    line_1.Color = real_CTF_color;
    
    line_2 = line([CTF_mean,CTF_mean],[0 80],'LineStyle','--')
    line_2.LineWidth = 5;
    line_2.Color = colormap(number,:);;
    
%     if number ==1
%         L.Position = [0.2    0.88    0.0847    0.0267];
%     elseif number ==2
%         L.Position = [0.65    0.88    0.0847    0.0267];
%     elseif number ==3
%         L.Position = [0.2   0.41    0.0847    0.0267];
%     elseif number ==4
%         L.Position = [0.65    0.41    0.0847    0.0267];
%     end


%     LOW_LINE = line([therold_low,therold_low],[0,200],'LineStyle','--','LineWidth',5,'Color','r');hold on
%      LOW_LINE = line([therold_high,therold_high],[0,200],'LineStyle','--','LineWidth',5,'Color','r');hold on
%     Real_Line = line([real_CTF_diff_mean,real_CTF_diff_mean],[0,200],'LineStyle','--','LineWidth',5,'Color','k');hold on
%     text(therold_low-0.001,210,'2.5%','FontSize',20,'Color','r')
%     text(therold_high-0.001,210,'97.5%','FontSize',20,'Color','r')
%      text(real_CTF_diff_mean-0.001,205,'real CTF mean','FontSize',15,'Color','k')
    xlabel('CTF slope','FontSize',fontsize)
    ylabel('Count','FontSize',fontsize)

    
    
    set(gca,'TickDir','out')
    box off
    %title(name(1:end-4),'FontSize',20)
    ax = gca;
    ax.LineWidth = 6;
    ax.YLim = [0 80];
     ax.XLim = [0.07 0.11];
ax.XTick=[0.08 0.1];

%     L.EdgeColor = [1,1,1];
%     L.Color = [1,1,1];

%     pic_path = [pic_folder filesep name(1:end-4)];
%     saveas(gca,pic_path,'jpg')
%     close all
end