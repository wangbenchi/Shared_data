%% compute variance

clc,clear
cd('J:\SL����\HBF\subject Z trial\Z eopch\-500 4000\60-100 Hz\all tar dis')

region_file = dir('*.mat');
condition = 'mixed dis';
response_network = {'Default','Limbic'};
%region_atlas ={'STG','MTG','amygdala','ACC'};
atlas_condition = 'FDR';
%region ={'precuneus','IP','hippocampus','PFC',};
%region_atlas = {'amygdala','STG','ACC'};
%exclude = {'bone','unknown'};
%region_atlas = 'Frontoparietal';
%region_atlas = {'precuneus','IP','hippocampus','PFC'};
%region = 'MTG';
prob_condition = 'non prob';
data_folder = ['\\desktop-nsg699e\g\��ʱ�������\SpatialIEM(���ԣ�\60-100 Hz (0-1500 ms corrected)\2022.9.22���·��� �޳����� �������ʣ�\' filesep 'Default+Limbic']; %% save path

ele_condition = 'region'; %% all,region
folder_condition = 'k-folder';%% k-folder,leave one out,K-min
cfg.mean_condition = 'yes';
cfg.CTF_condition ='yes'; %% if yes, just save the CTF not the spatialIEM
cfg.prob_condition = prob_condition;
cfg.eopch = [-500:2:1000];
%ele_folder = 'J:\SL����\HBF ele\����\Z score\60-100 Hz FDR\0-1500 ms (18������)';
ele_folder = 'J:\SL����\HBF ele\����\Z score\60-100 Hz FDR\0-1500 ms(18������ �޳�����������ʣ�';
atlas_folder =  ['J:\IEM\noise free\selelctive ele'];
for z = 1
    if strcmpi(condition,'only tar')
        load_trial_index = 'no';
%         network_atlas_path = [atlas_folder filesep 'Limbic +Default DK atals'];
%         load(network_atlas_path)
    elseif strcmpi(condition,'all trial dis')
        load_trial_index = 'no';
%         network_atlas_path = [atlas_folder filesep 'Limbic +Default DK atals'];
%         load(network_atlas_path)
    else
        load_trial_index = 'yes';
%         network_atlas_path = [atlas_folder filesep 'Limbic +Default DK atals'];
%         load(network_atlas_path)
    end
end
% load('H:\SL����\HBF ele\Spatial R\negitive ele.mat')
% RAW = all_negitive_atlas;
[NUM,TXT,RAW]=xlsread('J:\SL����\HBF ele\DK atlas.xlsx',2);
RAW(1,:)=[];
atlas_subject_info = RAW(:,10);
atlas_subject_info = strrep(atlas_subject_info,'''','');

subject_infor = RAW(:,5);
subject_infor = strrep(subject_infor,'''','');

atlas_subject_ele = RAW(:,10);


all_ele_atlas = RAW(:,2);


behave_folder =  ['J:\\SL����\behave\dis and mixed tar trial index']
% 
data_path= [data_folder filesep condition];
if ~exist(data_path)
    mkdir(data_path)
end

% 
% load('J:\SL����\HBF ele\����\Z score prob and non prob\all subject altas')
% subject_infor = all_ele_infor.all_ele_infor_subject;
% atlas_infor = all_ele_infor.all_ele_infor_atlas;
% ele_infor = all_ele_infor.all_ele_name;
% high_location_data = [];

% 
% [NUM,TXT,RAW]=xlsread('I:\�ں�ͼ\�缫��Ϣ\subject ele atlas.xlsx');
% RAW(1,:)=[];
% subject_infor = RAW(:,8);
% subject_infor = strrep(subject_infor,'''','');
% 
% location_folder='J:\SL����\each subject high location index';
% atlas_infor = RAW(:,6);
% atlas_infor = strrep(atlas_infor,'''','');

for n =1
    for x = 1
        all_subject_network_infro=[];
        clear tf_data_all ele_name ele_number tf_data_ele  
        fname =dir('*.mat');
        ele_number = 1;
        for i = 1:8
            eval([ 'location_' num2str(i) '_data =[];']);
        end

        for y = 1:length(region_file)
            clear fre_power
            clear atlas_data dim
            data_file = fname(y).name;
            load(data_file)
            if strcmpi(condition,'only tar')
                subject_name = data_file(1:end-51);
                ele_path = [ele_folder filesep 'only tar' filesep subject_name '_positive_only tar_ele_Z'];
            else
                subject_name = data_file(1:end-54);
                ele_path = [ele_folder filesep 'mixed dis none' filesep subject_name '_positive_mixed dis_ele_Z'];
            end
            %subject_name = name;
            if strcmpi(condition,'mixed tar dis')
                trial_index_path = [ behave_folder '\mixed tar dis\' prob_condition filesep subject_name '_mixed_tar_dis_trial'];
            elseif strcmpi(condition,'mixed tar')
                trial_index_path = [ behave_folder '\mixed tar\' prob_condition filesep subject_name '_mixed_tar_trial'];
            elseif strcmpi(condition,'mixed dis')
                trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep subject_name '_dis_trial'];  
            else
                trial_index_path=[];
            end
            clear real_ele_index positive_corr_ele 
%          
          load(ele_path)
%    
      
            subject_index = find(strcmpi(subject_infor,subject_name));

            
            %subject_ele = ele_infor(subject_index);

            
            
            subejct_network = RAW(subject_index,10);        
            subejct_network = strrep(subejct_network,'''','');
% 
             subejct_atlas_ele = RAW(subject_index,2);  
            subject_atals_info = RAW(subject_index,9);     
            subject_atals_info = strrep(subject_atals_info,'''','');
% 
            
            subejct_atlas_hel = RAW(subject_index,4);   
            subejct_atlas_hel = strrep(subejct_atlas_hel,'''','');
% 
% %             real_ele_all = ele_labels(ele_index);
            network_index = find(ismember(subejct_network,response_network));
%             
            network_ele = subejct_atlas_ele(network_index);
            network_atlas = subject_atals_info(network_index);
            netwrok_hel = subejct_atlas_hel(network_index);
            network_name = subejct_network(network_index);
%             
%             atlas_index = find(ismember(network_atlas,region_atlas));
%             atlas_ele = network_ele(atlas_index);
%             atlas_hel = netwrok_hel(atlas_index);
%             atlas_name = network_atlas(atlas_index);

% 

             all_subject_network_infro = [all_subject_network_infro;network_name]; 
%       
            %% �޳�IED �缫
            response_hel = strrep(netwrok_hel,'''','');
            atlas_real_name = {};
            for i =1:length(network_ele)
                ele_hel = response_hel{i};
                ele_name = network_ele{i};
                ele_name(end)=[];
                if strcmpi(ele_hel,'R')
                    ele_name = strrep(ele_name,'''''','''');
                end
                atlas_real_name{i} = ele_name;
            end
            exclude_IED_ele = intersect(real_ele_all,atlas_real_name);
%      


%             real_ele_all =atlas_ele;
%           response_hel = strrep(atlas_hel,'''','');
%             ele_labels = {dim.chans.labels};
%             all_ele = [1:length(ele_labels)];
%             ele_index = [];
%             for i =1:length(real_ele_all)
%                 ele_hel = response_hel{i};
%                 ele_name = real_ele_all{i};
%                 ele_name(end)=[];
%                 if strcmpi(ele_hel,'R')
%                     ele_name = strrep(ele_name,'''''','''');
%                 end
%                 ele_index(i) = find(strcmpi(ele_labels,ele_name));
%             end



    if strcmpi(ele_condition,'region')
            ele_labels = {dim.chans.labels};
            ele_index = [];
            for i =1:length(exclude_IED_ele)
                ele_name = exclude_IED_ele{i};
         
                ele_index(i) = find(strcmpi(ele_labels,ele_name));
            end
    elseif strcmpi(ele_condition,'all')
        ele_index = [1:length(dim.chans)];
    end





%             all_ele =  find(~ismember(all_ele, ele_index));
%             ele_index = ele_index(negitive_index);
%             real_name = ele_labels(ele_index);
            try
                fre_power = fre_power;
            catch
                fre_power = fre_power_alpha;
            end
            for i = 1:8
                eval([ 'location_' num2str(i) '_data_fre =[];']);
                eval([ 'location_' num2str(i) '_data_RT =[];']);
            end
            for i = 1:8
                eval([ 'location_' num2str(i) '_data_fre =fre_power{' num2str(i) '};']);
            end
            
            if strcmpi(load_trial_index,'yes')
                load(trial_index_path)
                for location = 1:8
                 clear data_location data_trial
                 eval(['data_trial =dis_location_all{' num2str(location) '}  ;'])
                 eval(['data_location =dis_location_index_location_all{' num2str(location) '};'])
                 for x = 1:length(data_location)
                     trial_index = data_trial(x);
                     trial_location = data_location(x);
                     eval([ 'location_' num2str(location) '_data_RT(:,:,x)= location_' num2str(trial_location) '_data_fre(ele_index,:,' num2str(trial_index) ');'])
                 end
                end
                
                
                if strcmpi(prob_condition,'prob')
                    prob_trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep subject_name '_dis_trial']; 
                    load(prob_trial_index_path)
                    trial_number = cellfun(@length,dis_location_all);
                    [~,high_location]= max(trial_number);

                    if strcmpi(condition,'mixed dis')
                         for i = 1:8
                             if i ==1
                                eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(high_location) '_data_RT);']);
                             else
                                 location_number = high_location+i-1;
                                 if location_number>8
                                     location_number = abs(location_number-8);
                                 end
                                eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(location_number) '_data_RT);']);
                             end
                         end
                        
                 
                    elseif strcmpi(condition,'mixed tar dis')
                        for i = 1:8
                             if i ==1
                                eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(high_location) '_data_RT(:,:,1:60));']);
                             else
                                 location_number = high_location+i-1;
                                 if location_number>8
                                     location_number = abs(location_number-8);
                                 end
                                eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(location_number) '_data_RT(:,:,1:60));']);
                             end
                        end
                    end
                else
                    for i = 1:8
                        eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(i) '_data_RT);']);
                    end
                end
                
                
            else
               for i = 1:8
                    clear trial_index
                    eval([ 'location_' num2str(i) '_data_RT =location_' num2str(i) '_data_fre(ele_index,:,:);']); 
                end
                if strcmpi(prob_condition,'prob')
                    prob_trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep subject_name '_dis_trial']; 
                    load(prob_trial_index_path)
                    trial_number = cellfun(@length,dis_location_all);
                    [~,high_location]= max(trial_number);

                    for i = 1:8
                             if i ==1
                                eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(high_location) '_data_RT(ele_index,:,1:90));']);
                             else
                                 location_number = high_location+i-1;
                                 if location_number>8
                                     location_number = abs(location_number-8);
                                 end
                                eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(location_number) '_data_RT(ele_index,:,1:90));']);
                             end
                         end
                else
                     for i = 1:8
                        eval([ 'location_' num2str(i) '_data =cat(1,location_' num2str(i) '_data,location_' num2str(i) '_data_RT);']);
                    end
                end
            end

            
        
        end

        
              for i = 1:8
                        eval([ 'fre_power_train{i} =location_' num2str(i) '_data;']);
              end
    %data_folder = 'G:\��ʱ�������\SpatialIEM(���ԣ�\Noise free\2022.9.22 (�·�����\FDR 5% (�޳�����缫 ��������)\surrogate data';
%     data_path = [data_folder filesep condition '_data'];
%     save(data_path,'fre_power_train','dim','condition','-v7.3');


%       
%               for i = 1:8
%                         eval([ 'fre_power_train{i} =location_' num2str(i) '_data;']);
%               end

%             
%               test_dim = dim;
%         data_path = ['K:\TF power\ITI and search onset (-1250 2500)\60-100 Hz(-1250 -2500)\test_data'];
%         save(data_path,'fre_power_test','test_dim','-v7.3')


%         %% k-folder, leave one out ������ã���Ϊ��ƽ������decoding and encoding, ����һ����Ӱ�첻�󣬼���û�б���
        %% 10 % percent ele
            addpath(genpath('\\Desktop-nsg699e\j\code\SL'));
            number = size(fre_power_train{1},1);
          
            iter_ele = floor(number*0.1);
            %train_data_folder ='G:\��ʱ�������\SpatialIEM(���ԣ�\Noise free\mixed dis noise free data';

            %iter_ele = 5;
            niter =10;
%         rng(seed)
%         data_folder = '\\Desktop-nsg699e\g\��ʱ�������\SpatialIEM(���ԣ�\Noise free\2022.9.22 (�·�����\FDR 5% (�޳�����缫 ��������)\max subject iter';
%         prob_condition = 'non prob'
%     
        cfg.mean_condition = 'yes';
        cfg.CTF_condition ='yes'; %% if yes, just save the CTF not the spatialIEM
        cfg.prob_condition = prob_condition;
        cfg.eopch = [0:2:1000];
%         number_list= [1:number];
%         number_list = shuffle(number_list);
        seed_number= randi([1,1000000]);
        seed =rng(seed_number);
            for z =1

                  iter_number = 1;
%                   subject_folder = [data_folder filesep num2str(z) filesep condition];
%                   %subject_folder = [data_folder filesep condition];
%                     if ~exist(subject_folder)
%                         mkdir(subject_folder)
%                     end
                    number_list= [1:number];
                    number_list = shuffle(number_list);
            for iter = 1:niter

                for x = 1
%                     seed_number= randi([1,1000000]);
%                     seed =rng(seed_number);

                    iter_number_list= number_list([1+iter_ele*(iter-1):iter_ele*(iter)]);
                    clear fre_power_atlas
                    write_name = [ 'all_subject_iter_' num2str(iter_number) '_' condition];
              
%                     for i = 1:8
%                         eval([ 'fre_power_atlas{i} =location_' num2str(i) '_data(iter_number_list,:,:);']);
%                     end
            
                    for i = 1:8
                        data = fre_power_train{i};
                        fre_power_atlas{i} =data(iter_number_list,:,:);
                    end
%                 data_save_path = [train_data_folder filesep num2str(iter)];
%                 save(data_save_path,'fre_power_atlas','iter','-v7.3')
%                 end
%                 prob_condition = 'non prob'
%                 data_folder = ['\\desktop-nsg699e\g\��ʱ�������\SpatialIEM(���ԣ�\Noise free\2022.9.22 (�·�����' filesep 'FDR 5%' filesep prob_condition]; %% save path
%                 condition = 'mixed tar'

                    %write_name = [ 'all_subject_iter_' num2str(x) '_' condition];
%                 iter_foler = [fName_folder filesep num2str(iter)];
%                 if ~exist(iter_foler)
%                     mkdir(iter_foler)
%                 end

                 cfg.seed = seed;
                    cfg.load_trial_index = 'no';
                    cfg.ele_labels = [1:size(fre_power_atlas{1},1)];
                    cfg.ele = cfg.ele_labels;
                    cfg.data_folder =data_path ;
                    cfg.attention_location = [1:8];
                    %cfg.trial_index = 'mixed dis';
                    cfg.ele_condition = 'atlas'; %% exclude,region, all
                    cfg.condition = condition;
                    cfg.subject_name = write_name;
                  
                    cfg.dim = dim;
                    cfg.nBlocks = 3;
                    cfg.winsize = 0;
                    cfg.nBins = 8;
                    %cfg.time = [-500:2:1000];
                     %cfg.train_epoch = [300 500];
                    cfg.window = 0;
                    cfg.step = 0;
                    cfg.mean_trial = 'yes';
                    cfg.data_condition = 'no';
                    cfg.power_condition = 'power';
                    cfg.save_train_data = 'no';%% if want to permutation
                    cfg.nIter =10;
                    cfg.report_condition = 'no';
                    cfg.save_CTF ='yes';

                    
                    %cfg.baseline = [-400 -100];
                    cfg.dowmsample_condition = 'no';
                    cfg.sinPower =7; %% 7 or 25
                    cfg.fre_power = fre_power_atlas;
                
                    
                    
%                     cfg.test_power = fre_power_test;
%                     cfg.test_dim = dim;
%                     cfg.test_time = [-500:2:1500];
% 
%                     cfg.train_power = fre_power_train;
%                     cfg.train_dim = dim;
                    %cfg.train_epoch = [300 500];
                    %comput_spatialIEM_cross_time_cross_data_noise(cfg)
                    comput_spatialIEM_each_ele(cfg);
                    % comput_spatialIEM_cross_time(cfg);
                     %comput_spatialIEM_cross_time_cross_data(cfg);
                    %comput_noise_corr(cfg);%% �������
                      
                    %comput_spatialIEM_only_high(cfg);
                    %lin_SVM_fre_mean(cfg);
                    %comput_spatialIEM_general_model(cfg);
                    

               
                iter_number = iter_number+1;
             end
           
            end
         
        end
        

        
    
    end
end

