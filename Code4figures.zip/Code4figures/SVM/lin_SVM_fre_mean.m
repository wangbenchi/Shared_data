%% SVM
% Rongqi lin
% 2/19/2021
% This matlab script peforms multiclass support vector machine analysis for the data reported in Bae & Luck (in press) NeuroImage.
% New decoding results might be slightly different from the results reported in the paper due to random shuffling.     
% See Bae & Luck (2018)J.Neuro for similar decoding analyses.
% 9/12/2018, GYB.
function lin_SVM_fre_mean(cfg)
v2struct(cfg);

for i = 1:8
    eval([ 'location_' num2str(i) '_data =[];']);
end
for i = 1:8
    eval([ 'location_' num2str(i) '_data_fre =fre_power{' num2str(i) '};']);
end
epoch = cfg.epoch;
epoch_index = dsearchn(dim.times',epoch');
dis_labels ={dim.chans.labels};
elelabels_all ={dim.chans.labels};
if strcmpi(ele_condition,'region')
    for i = 1:length(ele)
        ele_name = ele{i};
        ele_index(i) = find(strcmpi(dis_labels,ele_name));
    end
elseif strcmpi(ele_condition,'all')
    ele_index = [1:length(dis_labels)];
elseif strcmpi(ele_condition,'exclude')
    ele_index = [1:length(dis_labels)];
    for i = 1:length(ele)
        ele_name = ele{i};
        real_ele_index(i) = find(strcmpi(dis_labels,ele_name));
    end
    ele_index(real_ele_index)=[];
elseif strcmpi(ele_condition,'atlas')
    ele_index = [1:size(location_1_data_fre,1)];
end

if strcmpi(load_trial_index,'yes')
    %trial_index_path = ['P:\SL����\behave\dis and mixed tar trial index\mixed dis\non prob' filesep subject_name '_dis_trial'];
    load(trial_index_path)
    for location = 1:8
        clear data_location data_trial
         eval(['data_trial =dis_location_all{' num2str(location) '}  ;'])
         eval(['data_location =dis_location_index_location_all{' num2str(location) '};'])
         for x = 1:length(data_location)
             trial_index = data_trial(x);
             trial_location = data_location(x);
             eval([ 'location_' num2str(location) '_data_RT(:,:,' num2str(x) ')= location_' num2str(trial_location) '_data_fre(ele_index,epoch_index,' num2str(trial_index) ');'])
         end
    end
      for i = 1:8
        eval([ 'location_' num2str(i) '_data =location_' num2str(i) '_data_RT;']);
    end
else
    for i = 1:8
        clear trial_index
        eval([ 'location_' num2str(i) '_data_RT =location_' num2str(i) '_data_fre(ele_index,epoch_index,:);']); 
    end
    for i = 1:8
        eval([ 'location_' num2str(i) '_data =location_' num2str(i) '_data_RT;']);
    end
end


%% ȫ������ѵ��
if strcmpi(ele_condition,'atlas')
    elelabels_all = [1:length(ele_index)];
else
    elelabels_all = elelabels_all(ele_index);
    train_chanlabels =elelabels_all;
    test_chanlabels = elelabels_all;
end
for i = 1:8
    eval([ 'location_' num2str(i) '_marker = zeros(1,size(location_' num2str(i) '_data,3)) + ' num2str(i) ';']);
end




trian_events = cat(2,location_1_marker,location_2_marker,location_3_marker,location_4_marker,...
    location_5_marker,location_6_marker,location_7_marker,location_8_marker)';

test_events = trian_events;



train_data_all=[];
nbins = length(attention_location);
for i = 1:nbins
    location = attention_location(i);
    eval(['train_data_all = cat(3,train_data_all,location_' num2str(location) '_data);'])
end

for i = 1:nbins
    location= attention_location(i);
    eval([ 'each_location_trial(' num2str(location) ') = size(location_' num2str(location) '_data,3);']);
end
% 
% if strcmpi(prob_condition,'prob')
%     if strcmpi(condition,'mixed dis')
%         [~,high_location] = max(each_location_trial);
%         low_location = [1:8];
%         low_location(high_location)=[];
%         data_path = ['\\Desktop-nsg699e\j\SL����\each subject high location index\mixed dis' filesep subject_name '_high_location'];
%         save(data_path,'high_location','low_location')
%         
%     else
%         data_path = ['\\Desktop-nsg699e\j\SL����\each subject high location index\mixed dis' filesep subject_name '_high_location'];
%         load(data_path)
%     end
% end

% data_path = ['\\Desktop-nsg699e\j\SL����\each subject high location index\mixed dis' filesep subject_name '_high_location'];
% load(data_path)







svmECOC.nBins = nbins; % # of direction bin ����λ�ã���ԭ����������16������ģ���������ֻ��Ҫ������ɫ�ͷ���Ϳ����ˣ�����ҵ�bin��2
%svm_condition = 2, �����binָcondition

svmECOC.nIter = cfg.niter; % # of iterations �������ٴΣ������ϵ���Խ��ν��Խ�ȶ�����ʱ��ҲԽ��

svmECOC.nBlocks = nBlocks; % # of blocks for cross-validation ��ô����ѵ����Ͳ����顣������3-folder,Ҳ���ǽ����ݷֳ�3�ݣ�������Ϊѵ����һ����Ϊ����

%svmECOC.frequencies = dim.freqs; % frequency bands to analyze  / low pass filter �о������е�gammer��λ�ù�ϵ��������
fqs = 1;
svmECOC.time = dim.times(epoch_index);


nFreqs = 1;
svmECOC.bands = {'allFs'};
% svmECOC.Fs = EEG.srate; % sampling rate of pre-processed data ������downsample֮ǰ�Ĳ���Ƶ���Ƕ���
% svmECOC.window = 1000/svmECOC.Fs; % 1 data point per 4 ms  ԭ���Ĳ������Ƕ��٣���һ��ʱ���Ӧ���Ƕ���ms,����down��250hz�����һ��ʱ������1000/250=4ms
% svmECOC.time = -200:4:5496; % time points for re-sampling ��Ȥ��ʱ�䣬�����Ǿ���downsample�ģ�����Ԥ������ʱ��ͽ���downsample,�����ֶ�down��50hz��1000/50 = 20ms
%svmECOC.time = EEG.times
%ReleventChan = sort([2,3,4,18,19, 5,6,20, 7,8,21, 9,10,11,12,13,14, 22,23,24,25,26,27, 15,16,1,17]); %electrodes ��õ�ǰ��Ҫ�����ĵ缫,�һ�ֱ��д������Ҫ�����ĵ缫

svmECOC.nElectrodes = length(elelabels_all); % # of electrode included in the analysis ����һ���ж��ٸ��缫��Ҫ����
svmECOC.ReleventChan = elelabels_all;

mean_trial = cfg.mean_trial;
% for brevity in analysis
% ��֮ǰ�趨�õĲ����������
nBins = svmECOC.nBins;

nIter = svmECOC.nIter;

nBlocks = svmECOC.nBlocks;

times = svmECOC.time;

nElectrodes = svmECOC.nElectrodes;

nSamps = length(times);
% train_index = dsearchn(times',train_time');
% test_index = dsearchn(times',test_time');
% 
% train_times = times(train_index);
% 
% test_times = times(test_index(1):test_index(end));
% 
% train_nSamps = length(train_times);
% test_nSamps = length(test_times);

% if strcmpi(prob_condition,'prob')
%     svm_predict = nan(nFreqs,nIter,nSamps,nBlocks,1);  % a matrix to save predictions from SVM
%     tst_target = nan(nFreqs,nIter,nSamps,nBlocks,1);  % a matrix to save true target values 
% else
    svm_predict = nan(nFreqs,nIter,nSamps,nBlocks,nBins);  % a matrix to save predictions from SVM
    tst_target = nan(nFreqs,nIter,nSamps,nBlocks,nBins);  % a matrix to save true target values
% end
% 
% svm_predict = nan(nFreqs,nIter,nSamps,nBlocks,nBins);  % a matrix to save predictions from SVM
% tst_target = nan(nFreqs,nIter,nSamps,nBlocks,nBins);  % a matrix to save true target values




svmECOC.stimBin = trian_events'; 
stimBin_train = svmECOC.stimBin;

nTimes = length(svmECOC.time);

svmECOC.nTrials = length(stimBin_train); nTrials = svmECOC.nTrials; % # of trials ������ٸ�trial�������ԭ�����ݵ�trial������Ὣtrial����

%% ����͵�һFs��д����ͬ����Ϊ�˱�֤ÿ��Fs��trial����һ����
svmECOC.blocks = nan(nTrials,nIter);  % create svmECOC.block to save block assignments

for iter = 1:nIter
   %% preallocate arrays
    % train
    blocks = nan(size(stimBin_train));
    shuffBlocks = nan(size(stimBin_train));
    
    % count number of trials within each position bin
    % bin ������λ�ã���Ϊһ����16��λ�ã�����ÿ��block������16��bin
    % ���Խ�bin����Ϊcondition����һ��Ͱ���condition��˼·�ڸ�д
    % ��trial�漴���䵽����block �У�һ��block��Ϊtraining һ����testing

    clear binCnt
    clear binCnt_test

    for bin = 1:nBins
        binCnt(bin) = sum(stimBin_train == bin); 
    end


    minCnt = min(binCnt); % # of trials for position bin with fewest trials
  
    
    nPerBin = floor(minCnt/nBlocks); % max # of trials such that the # of trials for each bin can be equated within each block
                                     % �������ٵ�trial�Ƕ���



    % shuffle trials

    shuffInd = randperm(nTrials)'; % create shuffle index

    shuffBin = stimBin_train(shuffInd); % shuffle trial order
 



    % take the 1st nPerBin x nBlocks trials for each position bin.

    for bin = 1:nBins;   
        %train_marker = bin+10; %% ������Ҫ�޸� train
        %test_marker = bin+10; %% ����Ҳ��Ҫ�޸� test
        
        idx = find(shuffBin == bin); % get index for trials belonging to the current bin
       
        
        idx = idx(1:nPerBin*nBlocks); % drop excess trials
     

        x = repmat((1:nBlocks)',nPerBin,1); shuffBlocks(idx) = x; % assign randomly order trials to blocks
        

    end



    % unshuffle block assignment

    blocks(shuffInd) = shuffBlocks;
   


    % save block assignment

    svmECOC.blocks(:,iter) = blocks; % block assignment

    svmECOC.nTrialsPerBlock = length(blocks(blocks == 1)); % # of trials per block
    
  
    
end
 

for f = 1:nFreqs
    tic
    %��������
    % Loop through each iteration
    for iter = 1:nIter
        fprintf('��:\t%d ��\n',iter)
        blocks = svmECOC.blocks(:,iter);
 
        % Average data for each stimulus bin across blocks   
        stimBins = 1:nBins;

        if strcmpi (mean_trial,'yes')
            blockDat_filtData = nan(nBins*nBlocks,nElectrodes,nSamps);  % averaged & filtered EEG data
        else
            blockDat_filtData = nan(nBins*nBlocks,nElectrodes,nSamps,nPerBin);  % averaged & filtered EEG data
        end
        train_labels = nan(nBins*nBlocks,1);                              % bin labels for averaged & filtered EEG data
        %test_labels = nan(nBins*nBlocks,1);

        blockNum = nan(nBins*nBlocks,1);                            % block numbers for averaged & filtered EEG data
        bCnt = 1;
        clear i 
        for ii = 1:nBins
            for iii = 1:nBlocks
                if strcmpi(data_condition,'power')
                    if strcmpi (mean_trial,'yes')
                        blockDat_filtData(bCnt,:,:) = squeeze(mean(train_data_all(:,:,stimBin_train==stimBins(ii) & blocks'==iii),3));
                    else
                        blockDat_filtData(bCnt,:,:,:) = squeeze(train_data_all(:,:,stimBin_train==stimBins(ii) & blocks'==iii));
                    end
                elseif strcmpi(data_condition,'phase')
                    %data = squeeze(mean(exp(1i*train_data_all(:,:,stimBin_train==stimBins(ii) & blocks'==iii)),3));
                    %blockDat_filtData(bCnt,:,:) = squeeze(angle(mean(exp(1i*train_data_all(:,:,stimBin_train==stimBins(ii) & blocks'==iii)),3)));
                    blockDat_filtData(bCnt,:,:,:) = squeeze(angle(exp(1i*train_data_all(:,:,stimBin_train==stimBins(ii) & blocks'==iii))));
                end
             
                %blockDat_filtData_test(bCnt,:,:) = squeeze(mean(filtData_test(stimBin_test==stimBins(ii) & blocks_test==iii,:,tois),1));
                %blockDat_filtData(bCnt,:,:) = squeeze(mean(eegs(stimBin==stimBins(ii) & blocks==iii,:,:),1)); % �����Ȱ�trial����ƽ����Ȼ���ڽ���ѵ��
                train_labels(bCnt) = ii;
                %test_labels(bCnt)  = ii;
                blockNum(bCnt) = iii;
                bCnt = bCnt+1;
            end
        end
       
         %t = 1:Downsample-1
%          train_index = dsearchn(dim.times',train_time');
%          trnD_train_time = squeeze(mean(blockDat_filtData(:,:,train_index(1):train_index(end)),3));
%          
     tic

       for t = 1:nSamps
      
            % grab data for timepoint t
            % �ҵ���Ȥ����ʱ��㣬��֮ǰ�Ѿ��趨���ҵ���Ȥ���ˣ������Ҿ�ȫ���ӽ�ȥ����
            if cfg.winsize >0
                toi = ismember(times,times(t)-cfg.winsize/2:times(t)+cfg.winsize/2);
            else
                toi = t;
            end
            % time window of interest
%             train_toi = dsearchn(times',[train_times(t) train_times(t+1)]');
%             test_toi = dsearchn(times',test_times(t_test));
            if strcmpi (mean_trial,'yes')
                dataAtTimeTrain = squeeze(mean(blockDat_filtData(:,:,toi),3));  % total data
            else
                dataAtTimeTrain = squeeze(mean(blockDat_filtData(:,:,toi,:),3));  % total data
                dataAtTimeTrain = reshape(dataAtTimeTrain,[size(dataAtTimeTrain,1),size(dataAtTimeTrain,2)*size(dataAtTimeTrain,3)]);
             end
            %dataAtTimeTest = squeeze(mean(blockDat_filtData(:,:,t),3));  % total data
                                                                         %������Կ��Ǽ���ʱ������һ����з������������һ��ʱ���һ��ʱ�������������һ���ģ���һ��ʱ��������Ҫ��ʱ��Ƚϳ�
                                                                        %��Щ����Ϊ���������Ч�ʣ���ѵ����ʱ����20ms�ڵ�ʱ���ϲ���һ�����
            %dataAtTimeT = squeeze(mean(blockDat_filtData(:,:,time_index(1):time_index(end)),3));  % total data
%               dataAtTimeT = squeeze(blockDat_filtData(:,:,t));  % total data
            for block_number=1:nBlocks % loop through blocks, holding each out as the test set

                trnl = train_labels(blockNum~=block_number); % training labels
         
                
                tstl = train_labels(blockNum==block_number); % test labels
               
%                 high_index = find(tstl == high_location);
%                 tstl = tstl(high_index);
               trnD = dataAtTimeTrain(blockNum~=block_number,:);    % training data
               
                tstD = dataAtTimeTrain(blockNum==block_number,:);    % test data
               % tstD = tstD(high_index,:);
                % here define how to perform the learning
                mdl = fitcecoc(trnD,trnl, 'Coding','onevsall','Learners','SVM' );   %train support vector mahcine
                
                %% High
                LabelPredicted = predict(mdl, tstD);      % predict class of new data

                svm_predict(f,iter,t,block_number,:) = LabelPredicted;  % save predicted labels

                tst_target(f,iter,t,block_number,:) = tstl;             % save true target labels
                
                %-----------------------------------------------------%


        end
       
        end
   toc
    end

    toc % stop timing

end




% ��������
%OutputfName = strcat(saveLocation,'/',savecond,'ERP_',currentSub,'.mat');
data_folder = [fName_folder filesep condition];
if ~exist(data_folder)
    mkdir(data_folder)
end
data_root = [data_folder filesep subject_name '_band_SVM_Z.mat'];

svmECOC.targets = tst_target;
svmECOC.modelPredict = svm_predict; 
svmECOC.nBlocks = nBlocks;
% svmECOC.low_location = low_location;
% svmECOC.high_location = high_location;




save(data_root,'svmECOC','-v7.3');
end