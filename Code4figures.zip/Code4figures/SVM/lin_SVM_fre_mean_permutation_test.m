%% lin_SVM_permutation_test
% 2.20 2021

clc,clear
[filename filepath]=uigetfile('*.mat');
fname=dir(fullfile(filepath,'*.mat'));
network = 'mixed tar dis'
%subject_name='all trial dis 60-100 Hz'
location_folder = 'J:\SL����\each subject high location index\mixed dis';
tic
NBins = 8; % ����condition

for z =1
Nsub = length(fname);
Nblock = 3; % ����folder
Nitr = 10;  % ��������
simulations = 1000; % permutation ���Σ����˾����������д���е����ɣ�������������Ч��ȷʵ���
simulationT = nan(1,simulations);

Ntp = 751;
%create empty matrix
AverageAccuracy = zeros(Nsub,Ntp);

for sub = 1:Nsub


    %��������
    DecodingAccuracy = zeros(Ntp,Nblock,Nitr);
    % load decoding output files
    %fprintf('Subject:\t%d\n',id)
    filename = fname(sub).name;
    full_path = [filepath filename];
    load(full_path)
%     
%     subject_name = filename(1:end-22);
%     high_index = [location_folder filesep subject_name '_high_location'];
%     load(high_index);

    svm_predict = squeeze(svmECOC.modelPredict);
    svm_target = squeeze(svmECOC.targets);
    %tm = svmECOC.time;
    %high_location = svmECOC.high_location;
    %clear svmECOC

    for block = 1:Nblock
        for itr = 1:Nitr
            %TrueAnswer = shuffle(1:2);
            for tp = 1:Ntp  
%                 location =[1:8];
%                 location(high_location)=[];
                prediction = squeeze(svm_predict(itr,tp,block,:)); % this is prediction from models
                
               target = squeeze(svm_target(itr,tp,block,:)); % this is true target label
               % target = location';
               %target = high_location;
                Dist = target - prediction;
                ACC = mean(Dist==0);
            DecodingAccuracy(tp,block,itr) = ACC; % average decoding score

            end

        end
    end
      
     %now compute grand average for a participant

     grandAvg = squeeze(mean(mean(DecodingAccuracy,3),2));
     %grandAvg = abs(grandAvg - 0.5);
     %smoothedAvg = smooth(grandAvg,20);
     smoothedAvg = nan(1,Ntp);
     for tAvg = 1:Ntp
         if tAvg ==1
           smoothedAvg(tAvg) = mean(grandAvg((tAvg):(tAvg+2)));
         elseif tAvg ==2
           smoothedAvg(tAvg) = mean(grandAvg((tAvg-1):(tAvg+2)));
         elseif tAvg == (Ntp-1)
           smoothedAvg(tAvg) = mean(grandAvg((tAvg-2):(tAvg+1)));
         elseif tAvg == Ntp
           smoothedAvg(tAvg) = mean(grandAvg((tAvg-2):(tAvg)));
         else
           smoothedAvg(tAvg) = mean(grandAvg((tAvg-2):(tAvg+2)));  
         end

     end
     
     
     AverageAccuracy(sub,:) =smoothedAvg; % average across iteration and block
     
end %End of subject


bIter = 10000; % # of bootstrap iterations

    boot.IDX = nan(bIter,Nsub);
    boot.SLOPE = nan(bIter,Nsub,Ntp);
    boot.M = nan(bIter,Ntp);
    
    % loop through bootstrap replications
    for b = 1:bIter
        fprintf('Bootstrap replication %d out of %d\n', b, bIter)
    
        [bSLOPE idx] = datasample(AverageAccuracy,Nsub,1); % sample nSubs many observations from realSl for the subs dimensions (with replacement)
        boot.IDX(b,:) = idx;      % save bootstrap sample index
        boot.SLOPE(b,:,:) = bSLOPE;   % save bootstrapped CTFs
        boot.M(b,:) = mean(bSLOPE); % get the mean osbserved slope (across subs)
    
    end
    
    % calculate the bootstrapped SE
    boot.SE = std(boot.M);
    
    % calculate actual mean CTF
    ctfSlope.mn = mean(AverageAccuracy);
    
    %     % save slopes matrix
    ctfSlope.slopes = AverageAccuracy;

%now compute average accuracy across participants
subAverage = squeeze(mean(AverageAccuracy,1)); 
seAverage = squeeze(std(AverageAccuracy,1))/sqrt(Nsub); 

%% do cluster mass analyses
%releventTime = tStart:ntPerm; % from the onset of motion 

 
Ps = nan(2,Ntp);
for i = 1:Ntp% make sure this time range is correct
    %tp = releventTime(i);
    tp = i;
    [H,P,CI,STATS] =  ttest(AverageAccuracy(:,tp), 1/NBins,'tail','right'); % Test Against Zero
    %[H,P,CI,STATS] =  ttest(AverageAccuracy(:,tp), 0,'tail','right'); % Test Against Zero
    Ps(1,i) = STATS.tstat;
    Ps(2,i) = P;
end
% find significant points
candid = Ps(2,:) <= .05;
% time_index = find(candid);
% singnificant = zeros(1,length(tm));
% singnificant(time_index)=1;
% plot(tm,singnificant)

candid_marked = zeros(1,length(candid));
candid_marked(1,1) = candid(1,1);
candid_marked(1,length(candid)) = candid(1,length(candid));
%remove orphan time points
for i = 2:Ntp-1
    if candid(1,i-1) == 0 && candid(1,i) ==1 && candid(1,i+1) ==0
    candid_marked(1,i) = 0; 
    else
    candid_marked(1,i) = candid(1,i);     
    end
    
end

% combine whole time range with relevent time & significant information
clusters = zeros(Ntp,1);
clusterT = zeros(Ntp,1);
clusters(:,1) = candid_marked;
clusterT(:,1) = Ps(1,:);
clusterTsum = sum(Ps(1,logical(candid_marked)));

%%find how many clusters are there, and compute summed T of each cluster
tmp = zeros(10,25);
cl = 1;
member = 0;
for i = 2:length(clusters)-1
        if clusters(i-1) ==0 && clusters(i) == 1 && clusters(i+1) == 1 
        cl = cl+1;
        member = member +1;
        tmp(cl,member) = i;    
        
        elseif clusters(i-1) ==1 && clusters(i) == 1 && clusters(i+1) == 0 
        member = member +1;  
        tmp(cl,member) = i;    
        member = 0;  
        elseif clusters(i-1) ==1 && clusters(i) == 1 && clusters(i+1) == 1             
        member = member +1;  
        tmp(cl,member) = i;    
        
        else
        end
end


HowManyClusters = cl;
a = tmp(1:cl,:);
eachCluster = a(:,logical(sum(a,1)~=0));

%now, compute summed T of each cluster 
dat_clusterSumT = zeros(HowManyClusters,1);
for c = 1:HowManyClusters
   dat_clusterSumT(c,1) = sum(clusterT(eachCluster(c,eachCluster(c,:) ~=0)));
end
end

tm = svmECOC.time;
dat_clusterSumT;
%% find .05 point
% max T-Threshold
load('D:\SVM��SL��\decoding high location\1-3 Hz phase\all ele cos + sin\permutation\decording high location_mixed dis smooth 25 point_permutation') % load different null distribution of t-mass.
% load('simulationT256_ERP_Response.mat') % load different null distribution of t-mass.

iteration = 1000;
cutOff = iteration - iteration * 0.05; %one tailed
% sortedTvlaues = sort(EmpclusterTvalue,2);
critT = simulationT(cutOff); % 2 tailed iteration * 0.025
sigCluster = dat_clusterSumT > critT;
draw = eachCluster(sigCluster,:);
draw = sort(reshape(draw,1,size(draw,1)*size(draw,2)));
draw = draw(draw>0);

for si = 1 :size(dat_clusterSumT,1)
    
[~,where] = min(abs(simulationT - dat_clusterSumT(si)));
 pv = 1 - where/iteration
end

data_dir = ['G:\��ʱ�������\SVM AC\gamma �������� �޳�����\permutation test\' network]
save(data_dir,'subAverage','draw','seAverage','tm','boot');
%% plot significant clusters
tm = svmECOC.test_time;
tm = svmECOC.time;
sig_time = tm(draw);
%tm = [-1000:2:1500];
%tm = svmECOC.time;
%Ntp = 1251;
sigcluster = eachCluster(:);
sigcluster(sigcluster==0) =[];
cl=colormap(parula(50));
figure()
accEst = squeeze(subAverage);
w = zeros(Ntp,1)';
w(draw)=1;
a = area(tm, accEst.*w);
a.EdgeColor = 'none';
a.FaceColor = [0.8,0.8,0.8];
child = get(a,'Children');
set(child,'FaceAlpha',0.9)
hold on
%mEI = boundedline(tm,subAverage,seAverage, 'cmap',cl(42,:),'alpha','transparency',0.35);
plot(tm,subAverage);
title('Decoding location','FontSize',18)
xlabel('Time (ms)','FontSize',18);ylabel('Decoding Accuracy','FontSize',18)
ax = gca;
%ax.YLim = [0.4, 0.9];
%xtime = [0 500 1000 1500];

%ax.XTickLabel = {'0','500','1000','1500','2000','2500','3000','3500','4000'};
h = line(tm,1/8* ones(1,Ntp));
h.LineStyle = '--';
h.Color = [0.1,0.1,0.1];