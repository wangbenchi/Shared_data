 % test: high-1
% rong qi lin
% 12.25.2020
clc,clear
%% Prob vs Non prob
cd('\\desktop-nsg699e\j\SL����\HBF\subject Z trial\Z eopch\-500 4000\60-100 Hz\all tar dis')
addpath(genpath('\\Desktop-nsg699e\j\code\SL\SVM'))
addpath('\\Desktop-nsg699e\k\SVM phase')
%cd('\\Desktop-nsg699e\d\SL result\SL trial power\ITI onset\prob')
[filename filepath]=uigetfile('*.mat');
fname = dir(fullfile(filepath,'*.mat'));
all_number = length(fname);
ele_folder = '\\Desktop-nsg699e\j\SL����\HBF ele\����\Z score\60-100 Hz FDR\0-1500 ms(18������ �޳�����������ʣ�';
behave_folder = ['\\Desktop-nsg699e\j\SL����\behave\dis and mixed tar trial index']
condition = 'mixed tar dis';

ele_condition = 'region';%% region, all, atlas
prob_condition = 'non prob';
fName_folder = ['\\Desktop-nsg699e\g\��ʱ�������\SVM AC\gamma �������� �޳�����' filesep prob_condition ];
if ~exist(fName_folder)
    mkdir(fName_folder)
end
% 
% exclude = {'bone','unknown','none'};
% [NUM,TXT,RAW]=xlsread('\\Desktop-nsg699e\i\�ں�ͼ\�缫��Ϣ\subject ele atlas.xlsx');
% RAW(1,:)=[];
% subject_infor = RAW(:,8);
% subject_infor = strrep(subject_infor,'''','');
% 
% 
% atlas_infor = RAW(:,6);
% atlas_infor = strrep(atlas_infor,'''','');
% 
%  other_frequency = '\\Desktop-nsg699e\k\phase\hilber phase\1-3 Hz\Fixation onset'
% labels_fodler = '\\Desktop-nsg699e\j\SL����\bioplar clean\fixation onset\non prob'


for id = 3
    clear real_ele_all fre_power name ele_name_all
    subject_file = fname(id).name;
    data_path = [filepath subject_file];
%     load(subject_file)
%     name = subject_name;
%     gamma_path = ['I:\SL����\HBF\subject Z trial\Z eopch\-500 4000\60-140 Hz\all tar dis none' filesep name '_TF_output_all_tar_dis_none_conavg_HFB_gamma_Z'];
%     load(gamma_path)
    if  strcmpi(condition,'only tar')
        name = subject_file(1:end-47);
    else
        name = subject_file(1:end-54);
        
    end
    load(data_path)
%     
%     ele_labels_path = [labels_fodler filesep name '_dis_none'];
%     load(ele_labels_path,'ele_refernce_labels')
%     
%      cfg=[];
%      dim.times = [-1000:2:1500];
%     cfg.train_power = cue_power;
%     cfg.train_dim = dim;
%     cfg.train_epoch = [500 1000];
%   
% 
% %     clear fre_power dim
% %                 
%         other_frequency_path = [other_frequency filesep name '_mixed_dis_high_power_8_12_hz'];
%         load(other_frequency_path);
%    
% 
%     dim.times = [-1250:2:1000]+1250;
%     cfg.test_power = ITI_power;
%     cfg.test_dim = dim;
%     cfg.test_time = [-0:2:2000];
%     
    if strcmpi(condition,'mixed tar dis')
        trial_index_path = [ behave_folder '\mixed tar dis\' prob_condition filesep name '_mixed_tar_dis_trial'];
        ele_path = [ele_folder filesep 'mixed dis none' filesep name '_positive_mixed dis_ele_Z'];
        cfg.load_trial_index = 'yes';
    elseif strcmpi(condition,'mixed tar')
        trial_index_path = [ behave_folder '\mixed tar\' prob_condition filesep name '_mixed_tar_trial'];
        ele_path = [ele_folder filesep 'mixed dis none' filesep name '_positive_mixed dis_ele_Z'];
        cfg.load_trial_index = 'yes';
    elseif strcmpi(condition,'mixed dis')
         trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep name '_dis_trial'];
        ele_path = [ele_folder filesep 'mixed dis none' filesep name '_positive_mixed dis_ele_Z'];
        cfg.load_trial_index = 'yes';
    elseif strcmpi(condition,'all trial dis')
        ele_path = [ele_folder filesep 'mixed dis none' filesep name '_positive_mixed dis non_ele_Z'];
        trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep name '_dis_trial'];  
        cfg.load_trial_index = 'no';
    elseif strcmpi(condition,'only tar')
        ele_path = [ele_folder filesep 'only tar' filesep name '_positive_only tar_ele_Z'];
        trial_index_path = [ behave_folder '\mixed dis\' prob_condition filesep name '_dis_trial'];  
        cfg.load_trial_index = 'no'; 
    end
    load(ele_path)

    
        
%     
%     labels_path =['H:\SL trial hibler phase\alpha\prob' filesep name];
%     load(labels_path)
%     RSM_time = permute(RSM_time,[2,1,3]);
%     fre_power=[];
%     for location = 1:8
%         eval(['data_trial =tar_' num2str(location) '_trial;']);
%         fre_power{location} = RSM_time(:,:,data_trial);
%     end
%     dim=[];
%     dim.ele_labels = ele_labels;
%     dim.times = squeeze(mean(toi,2));
    
    
%     
%      subject_index = find(strcmpi(subject_infor,name));
%     subject_atlas = atlas_infor(subject_index);
% 
%     subject_ele = ele_labels;
%     
%     region_index = find(~ismember(subject_atlas,exclude));
%     real_ele_all = subject_ele(region_index);

if strcmpi(ele_condition,'region')
    ele_labels = {dim.chans.labels};
    real_ele_index = [];
    for i =1:length(real_ele_all)
     
        ele_name = real_ele_all{i};
        real_ele_index(i) = find(strcmpi(ele_labels,ele_name));
    end
else
     ele_labels = {dim.chans.labels};
   
    real_ele_index = [1:length(ele_labels)];

end


%     trial_list=[];
%     for location = 1:8
%         eval(['trial_list{location} = dis_1' num2str(location) '_trial;'])
%     end
    
% 
%     dim=[];

   if length(real_ele_all)>0
        cfg.fName_folder = fName_folder; %% data save folder
        %cfg.trial_index = 'mixed dis';
        cfg.attention_location = [1:8];
        cfg.prob_condition = prob_condition;
        cfg.ele_condition =ele_condition; %% exclude,region, all
        cfg.trial_index_path = trial_index_path;
        cfg.condition = condition;
        cfg.subject_name = name;

 
%         
       % dim.chans.labels = ele_refernce_labels;
        cfg.dim = dim;
        cfg.fre_power = fre_power;
        cfg.winsize = 0;
        cfg.sinPower = 7; %% 7 or 25
        cfg.epoch = [0:2:1000];
        cfg.ele_labels = {dim.chans.labels};
        %cfg.dowmsampel = [-500:10:1500];
        cfg.nBlocks = 3;
        cfg.nBins = 8;
        cfg.ele = real_ele_all;
        cfg.frequency = 2;
        cfg.niter = 10;
        cfg.mean_trial = 'yes';
        cfg.data_condition = 'power';
          
          %% train
        %dim.times =times;
%         dim.chans.labels = ele_refernce_labels;
%         cfg.train_dim = dim;
%         cfg.train_time = [200 800];
%         cfg.train_data = fre_power;
%         %% test
% %         test_data = [other_frequency filesep subject_file];
% %         load(test_data)
% 
%         %dim.times =times;
%         cfg.test_dim = dim;
%        % cfg.test_epoch = [-1000:2:1500];
%         cfg.test_epoch = [4000:2:6000];
%         cfg.test_data = fre_power;
%         cfg.location_data_folder = '\\Desktop-nsg699e\j\SL����\each subject high location index\mixed dis';
% %         
%         
         %cfg.trial_list = trial_list;
        %lin_SVM_fre_mean_low_high_cross_data(cfg)
         %lin_SVM_fre_mean_low_high_cross_data_each_ele(cfg)
        %lin_SVM_fre_mean_corss_time_cross_data_phase(cfg)
        lin_SVM_fre_mean(cfg);
        %lin_SVM_phase_hilber(cfg);
%         lin_SVM_fre_mean_corss_time(cfg);
        %lin_SVM_fre_mean_corss_time_cross_data(cfg);
        %lin_SVM_high_and_low_corss_time(cfg);
        %lin_SVM_high_and_low(cfg)
       % lin_SVM_high_and_low_phase(cfg);
        
%         cfg.train_time = time_cue;
%         cfg.test_time = time_ITI;
%         cfg.train_data = ele_phase_cue;
%         cfg.test_data = ele_phase_ITI;
%         cfg.train_epoch = [200 400];
%         cfg.trial_event = trial_event;
%         cfg.ele_labels = ele_labels;
%         lin_SVM_fre_phase(cfg);
        %lin_SVM_fre_mean_phase(cfg);
        %lin_SVM_fre_trial_phase(cfg)
        %lin_SVM_prob_vs_non_prob(cfg)
    end
end
clc,clear

