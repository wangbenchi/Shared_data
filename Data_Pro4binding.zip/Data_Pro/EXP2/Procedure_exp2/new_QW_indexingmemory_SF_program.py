#!/usr/bin/env python
# -*- coding: utf-8 -*-

#### import libraries

import pygame, sys, random, gc, os, csv, time
from pygame.locals import *
from math import sin, cos, pi, atan, sqrt
from psychopy import visual, core
from colorpy import colormodels
import numpy as np

####Define variable
scn_size = (1440,900)
deg2pix  = int(scn_size[0]/(atan(24.0/71)*360/pi))
mytex    = np.array([[1, 0]])
sti_oris  = [0, 45, 90, 135]
sti_SF = [0.7,1.2,2.2,4.2]
green = [0,255,0]
black = [0,0,0]
red = [255,0,0]
blue = [0,0,255]
yellow = [255,255,0]
color = [green,yellow,red,blue]


# Get subject information
def get_subj_info():

    """ collect participant information """
    subj   = raw_input("Assign a subject ID (experimenter): ")
    name   = raw_input("Give two random letters to label the subject: ")
    gender = raw_input("Subject's gender is(f/m): ")
    age    = raw_input("Subject's age is: ")
    Pro    = raw_input("Probe(index/noindex): ")

    return [subj, name, gender, age, Pro]

## Data manipulation functions #################################################
def init_data_file(SUBJ_INFO):

    """ define a function that initializes the data file and get sub_info"""
    if not os.path.exists('csv_data'): os.mkdir('csv_data')
    file_name = 'csv_data/' + SUBJ_INFO[0] + '_' + SUBJ_INFO[1] + '_' + SUBJ_INFO[4] + '.csv'
    data_file = open(file_name, 'w')
    header = ['subj', 'name', 'gender', 'age', 'cond',
          'P_resp', 'P_startTime', 'P_respTime', 'P_gotKey',
          'sf1', 'sf2', 'sf3', 'sf4',
          'ord_1', 'ord_2', 'ord_3', 'ord_4',
          'task', 'correct_key', 'no_change', 'mode']

    data_file.write(','.join(header)+'\n')
    return data_file

SUBJ_INFO = get_subj_info()
Cond       = SUBJ_INFO[4]
DATA_FILE = init_data_file(SUBJ_INFO)

#create a window
myWin = visual.Window(size=scn_size, units='pix', fullscr=False, allowGUI=False, color=(0,0,0), winType='pygame')
pygame.mouse.set_visible(False)

#### Wait functions ####################################################
def wait4key(DURATION, KEYS_ALLOWED = [], ALLOW_QUIT = True ):

    """    John Christie's wait4key() function.
    KEYS_ALLOWED should be a list, like [K_SPACE, K_l]
    ALLOW_QUIT = True, exit when Esc key pressed. """

    # set up a few variables
    timeOut = False; gotKey = False
    startTime = pygame.time.get_ticks()
    pygame.event.clear()

    while not (timeOut or gotKey):
        # check for time out
        current_time = pygame.time.get_ticks()
        if current_time >= (DURATION + startTime):
            timeOut = True
            break
        
        # check for button press
        for keyp in pygame.event.get():
            if (keyp.type == KEYDOWN):
                # exit pygame if Escape is pressed
                if (keyp.key == K_KP_MULTIPLY) and ALLOW_QUIT :
                    pygame.quit(); sys.exit();
                if keyp.key in KEYS_ALLOWED:
                    gotKey   = True
                    respKey  = pygame.key.name(keyp.key)
                    respTime = current_time

    if gotKey:
        key_resp = [True, startTime, respTime, respKey]
    else:
        key_resp = [False, startTime, None, None]

    return key_resp

# put the stimuli in cache
text    = visual.TextStim(win=myWin, font='STXINWEI', height=40)
sti_ori = visual.Rect(win=myWin, width=0.5*deg2pix, height=2.5*deg2pix,lineWidth=2,lineColor=(-1,-1,-1),fillColor=(-1,-1,-1))
sti_shape = visual.Circle(win=myWin,radius=deg2pix,lineWidth=2)
fix1    = visual.Line(win=myWin, start=(-deg2pix/4, 0), end=(deg2pix/4, 0), lineColor=(-1,-1,-1),lineWidth=2)
fix2    = visual.Line(win=myWin, start=(0, -deg2pix/4), end=(0, deg2pix/4), lineColor=(-1,-1,-1),lineWidth=2)
sti1_grating  = visual.GratingStim(win=myWin, tex=mytex, size=2*deg2pix, sf=None, mask='circle',pos=(0,0), phase=0.25)


#### define a function to draw stimulus on display
def draw_sti(display, probe, SF, c, o, no_change, change_ori, change_col, order):
    
    ### draw all stimulate  
    if display=='sample':                        
        for i in order:
            if i%2==0:
                sti1_grating.setColor(c[i/2], 'rgb255')
                sti1_grating.setOri(90)
                sti1_grating.sf=(SF[i]/deg2pix)
                sti1_grating.draw()
                myWin.flip()
                core.wait(0.3)
                myWin.flip()
                core.wait(0.2)
            else:
                sti1_grating.setColor(black, 'rgb255')
                sti1_grating.setOri(o[(i-1)/2])
                sti1_grating.sf=(SF[i]/deg2pix)
                sti1_grating.draw()
                myWin.flip()
                core.wait(0.3)
                myWin.flip()
                core.wait(0.2)

    if display == 'detection' :
        if no_change%2 == 0:
            det_c = no_change/2
        else:
            det_c = (no_change-1)/2
            
        if probe == 'nochange_col':
                sti1_grating.setColor(c[det_c], 'rgb255')
                sti1_grating.setOri(90)
                sti1_grating.sf=(SF[no_change]/deg2pix)
                sti1_grating.draw()
        if probe == 'nochange_ori':
                sti1_grating.setColor(black, 'rgb255')
                sti1_grating.setOri(o[det_c])
                sti1_grating.sf=(SF[no_change]/deg2pix)
                sti1_grating.draw()
        if probe == 'change_col':
                sti1_grating.setColor(change_col[0], 'rgb255')
                sti1_grating.setOri(90)
                sti1_grating.sf=(SF[no_change]/deg2pix)
                sti1_grating.draw()
        if probe == 'change_ori':              
                sti1_grating.setColor(black, 'rgb255')
                sti1_grating.setOri(change_ori[0])
                sti1_grating.sf=(SF[no_change]/deg2pix)
                sti1_grating.draw()
        

#### preparing the instructions for the task ############################
def instructions(MODE):
    if MODE == 'prac':
        if Cond == 'index':
            insImage = visual.ImageStim(win=myWin,image='instr-index.png')
        else:
            insImage = visual.ImageStim(win=myWin,image='instr-noindex.png')
        insImage.draw()

    if MODE == 'test':
        text.setPos((0,0))
        text.setText('Press space to continue!')
        text.draw()

    myWin.flip()
    wait4key(sys.maxint, [K_SPACE], True) # wait infinitely or for the key

#### Here is the trial list with all conditions ###############################
#               change    response
trial_list = [['change_ori',     '/'],
              ['change_col',     '/'],
              ['nochange_ori',      'z'],
              ['nochange_col',      'z']]

##### run a single trial ######################################################
def run_trial(task, subj_info, data_file, mode):
    
    # Set the default value for response
    PRESP = [None]*4

    if Cond == 'index':
        
        SF = random.sample(sti_SF, 2)
        SF = SF+SF
        random.shuffle(SF)
    if Cond == 'noindex':
        SF = random.sample(sti_SF, 4)
        random.shuffle(SF)
        
    order = random.sample(range(4),4)    # the display order of simple items
    no_change = random.choice(order) # item will be detected.

    c = random.sample(color, 2)
    o = random.sample(sti_oris, 2)


    change_col = [cc for cc in color if not cc in c]
    change_col = random.sample(change_col,1)
    change_ori = [ori for ori in sti_oris if not ori in o]
    change_ori = random.sample(change_ori,1)
    
    fix1.draw();fix2.draw()
    myWin.flip()
    wait4key(500)

    myWin.flip()
    wait4key(500)
    
    # now draw the sample display 
    draw_sti('sample', task[0], SF, c, o, no_change, change_ori, change_col, order)

    # present the interval display for 900 ms
    myWin.flip()
    wait4key(1000)

    # now draw the detection display till response
    draw_sti('detection', task[0], SF, c, o, no_change, change_ori, change_col, order)
    myWin.flip()
    PRESP = wait4key(sys.maxint, [K_z, K_SLASH], True)

    # present the interval display for random time
    myWin.flip()
    wait4key(random.randint(350,550))

    trial_data = subj_info + PRESP + SF + order + task + [no_change, mode]
    trial_data = map(str, trial_data) # change all elements to 'string' type
    data_file.write(','.join(trial_data) + '\n')

#### start experiment #########################################################
def run_experiment(mode):
    """ define a function to test different conditions """
    # mode could be 'practice' or 'testing'
    
    if mode == 'practice':
        instructions('prac')      # present the instructions
        test_list = trial_list[:]*5
            
    if mode == 'testing':
        instructions('test')      # present the instructions
        test_list = trial_list[:]*20

# run the testing/practicing trials and recycle trials with errors
    random.shuffle(test_list)
    for task in test_list[:]:
        run_trial(task, SUBJ_INFO, DATA_FILE, mode)

                                                 
run_experiment('practice')
for i in range(2):
    run_experiment('testing')

#### end experiment, display a message and do the clean-up
text.setText('Experiment finished!')
text.setPos((0,0))
text.draw()
myWin.flip()
wait4key(2000)
        
# Close the DATA file
DATA_FILE.close()

#Close the experiment graphics
myWin.close()

